package com.example.livecam

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView

/** ImageView with pinch zoom, pan, double tap and long press. */
class ZoomImageView(c: Context) : ImageView(c) {
    var onZoom: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onSwipeDown: (() -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var held = false
    private var s = 1f
    private var lx = 0f
    private var ly = 0f
    private var prevN = 0

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoom(s * d.scaleFactor); return true }
    })
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onDoubleTap(e: MotionEvent): Boolean { if (s > 1f) reset() else zoom(2.5f); return true }
        override fun onLongPress(e: MotionEvent) { if (s == 1f) { held = true; parent.requestDisallowInterceptTouchEvent(true); onLong?.invoke() } }
    })

    private fun zoom(z: Float) {
        if (z > 1f) onZoom?.invoke()
        s = z.coerceIn(1f, 5f)
        scaleX = s; scaleY = s
        clamp()
    }

    private fun clamp() {
        val mx = width * (s - 1) / 2
        val my = height * (s - 1) / 2
        translationX = translationX.coerceIn(-mx, mx)
        translationY = translationY.coerceIn(-my, my)
    }

    fun reset() { s = 1f; scaleX = 1f; scaleY = 1f; translationX = 0f; translationY = 0f }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) { downX = e.rawX; downY = e.rawY }
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        if (s > 1f || e.pointerCount > 1) parent.requestDisallowInterceptTouchEvent(true)
        val n = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) 0 else e.pointerCount
        if (e.actionMasked == MotionEvent.ACTION_MOVE && n == 1 && prevN == 1 && s > 1f) {
            translationX += e.rawX - lx
            translationY += e.rawY - ly
            clamp()
        }
        if (e.actionMasked == MotionEvent.ACTION_UP && !held && s == 1f &&
            e.rawY - downY > 120f * resources.displayMetrics.density &&
            kotlin.math.abs(e.rawX - downX) < (e.rawY - downY) * 0.7f) {
            onSwipeDown?.invoke()
        }
        if (held && (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL)) {
            held = false; onRelease?.invoke()
        }
        lx = e.rawX; ly = e.rawY; prevN = n
        return true
    }
}

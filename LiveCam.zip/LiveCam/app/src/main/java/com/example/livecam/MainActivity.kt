package com.example.livecam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.min

class Frame(val ts: Long, val arrival: Long, val luma: Int)
class AudioChunk(val data: ByteArray, val startNs: Long)
class Sample(val data: ByteArray, val pts: Long, val flags: Int)
class Shot { @Volatile var ts = 0L; @Volatile var jpeg: ByteArray? = null }

class MainActivity : AppCompatActivity() {

    companion object {
        const val PRE_NS = 1_500_000_000L   // 1.5 s before the tap
        const val POST_NS = 1_500_000_000L  // 1.5 s after the tap
        const val SAMPLE_RATE = 44100
        const val SHUTTER_COOLDOWN_MS = 300L      // min time between two shutter presses
        const val MAX_JOIN_NS = 6_000_000_000L    // a burst joins one long Live up to this long
        const val MAX_PENDING = 6
        const val MAX_BURST = 12                  // max photos joined in one long Live
        const val VIDEO_FPS = 60
        const val VIDEO_BITRATE = 8_000_000
        const val SHOW_FPS_TOAST = true           // shows the real fps of each saved Live
        const val SCREEN_FLASH_HOLD_MS = 900L   // how long the front flash stays on after the shot
        const val AUDIO_OFFSET_US = 0L      // ajusta si el audio sale adelantado/atrasado
        val YELLOW = Color.parseColor("#FFD60A")
    }

    private lateinit var previewView: PreviewView
    private lateinit var previewFrame: View
    private lateinit var status: TextView
    private lateinit var flashBtn: ImageView
    private lateinit var thumb: ImageView
    private lateinit var flipBtn: ImageView
    private lateinit var flashOverlay: View
    private lateinit var zoomPill: View
    private lateinit var shotFlash: View
    private lateinit var flipCover: View
    private lateinit var shutterBtn: View
    private var flipping = false
    private lateinit var focusRing: View
    private val hideRing = Runnable {
        focusRing.animate().alpha(0f).setDuration(300).withEndAction { focusRing.visibility = View.INVISIBLE }.start()
    }
    private lateinit var zoomViews: List<TextView>

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var hiRes = false
    private lateinit var resBtn: TextView
    private var facingFront = false
    private var lens = 1                 // 0 = 0.6x, 1 = 1x, 2 = 2x
    private var pinchRatio: Float? = null
    private var flashState = 0           // 0 auto, 1 on, 2 off
    private var ultraId: String? = null
    private var ultraActive = false
    @Volatile private var busy = false
    private var prevBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
    private val uiHandler = Handler(Looper.getMainLooper())

    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val encodeExecutor = Executors.newSingleThreadExecutor()

    private val lock = Any()
    private val buffer = ArrayDeque<Frame>()
    private val videoBuf = ArrayDeque<Sample>()   // rolling H.264 samples (pts = sensor time in us)
    private var enc: MediaCodec? = null
    private var encW = 0
    private var encH = 0
    @Volatile private var encFormat: MediaFormat? = null
    private val audioBuffer = ArrayDeque<AudioChunk>()
    @Volatile private var audioRunning = false
    private var capturing = false
    private val shots = ArrayList<Shot>()
    private var pendingPhotos = 0
    private var lastShutterMs = 0L
    private var torchOn = false
    private val ioExecutor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        previewFrame = findViewById(R.id.previewFrame)
        status = findViewById(R.id.status)
        flashBtn = findViewById(R.id.flashBtn)
        thumb = findViewById(R.id.thumb)
        flipBtn = findViewById(R.id.flipBtn)
        flashOverlay = findViewById(R.id.flashOverlay)
        zoomPill = findViewById(R.id.zoomPill)
        shotFlash = findViewById(R.id.shotFlash)
        flipCover = findViewById(R.id.flipCover)
        shutterBtn = findViewById(R.id.shutter)
        previewView.previewStreamState.observe(this) {
            if (it == PreviewView.StreamState.STREAMING && flipping) fadeBackIn()
        }
        focusRing = findViewById(R.id.focusRing)
        zoomViews = listOf(R.id.z06, R.id.z1, R.id.z2).map { findViewById<TextView>(it) }

        // 3:4 preview, same as the photo
        previewFrame.post {
            val lp = previewFrame.layoutParams
            lp.height = previewFrame.width * 4 / 3
            previewFrame.layoutParams = lp
        }

        findViewById<View>(R.id.shutter).setOnClickListener { onShutter() }
        flashBtn.setOnClickListener { cycleFlash() }
        flipBtn.setOnClickListener { flipCamera() }
        thumb.setOnClickListener { startActivity(Intent(this, GridActivity::class.java)) }
        hiRes = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("hiRes", false)
        resBtn = findViewById(R.id.resBtn)
        updateResUi()
        resBtn.setOnClickListener {
            if (busy) return@setOnClickListener
            hiRes = !hiRes
            getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("hiRes", hiRes).apply()
            updateResUi()
            bindCamera()
        }
        zoomViews.forEachIndexed { i, v -> v.setOnClickListener { selectLens(i) } }
        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { pinchZoom(d.scaleFactor); return true }
        })
        val taps = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
        })
        previewView.setOnTouchListener { _, e -> scaler.onTouchEvent(e); taps.onTouchEvent(e); true }
        updateFlashUi()
        updateZoomUi()

        if (hasPermission()) {
            startAll()
            // Needed so the saved XMP (Live info) is readable from the gallery
            if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_MEDIA_LOCATION) != PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_MEDIA_LOCATION), 11)
        } else {
            val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            else perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= 28) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT >= 29) perms.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), 10)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshThumb()
    }

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (!hasPermission()) { finish(); return }
        if (cameraProvider == null) startCamera()
        startAudio()
        refreshThumb()
    }

    private fun updateResUi() {
        resBtn.text = if (hiRes) "48MP" else "NORMAL"
        resBtn.setTextColor(if (hiRes) 0xFFFFD60A.toInt() else 0xFFFFFFFF.toInt())
    }

    // ---------- Thumbnail ----------

    private fun refreshThumb() {
        Thread {
            val latest = Media.queryLive(this).firstOrNull()
            if (latest != null) loadThumb(latest)
        }.start()
    }

    private fun loadThumb(uri: Uri) {
        Thread {
            val bmp = Media.decode(this, uri, 256)
            runOnUiThread { if (bmp != null) thumb.setImageBitmap(bmp) }
        }.start()
    }

    // ---------- Flash ----------

    private fun updateFlashUi() {
        when (flashState) {
            1 -> { flashBtn.setImageResource(R.drawable.ic_flash_on); flashBtn.setColorFilter(YELLOW) }
            2 -> { flashBtn.setImageResource(R.drawable.ic_flash_off); flashBtn.setColorFilter(Color.WHITE) }
            else -> { flashBtn.setImageResource(R.drawable.ic_flash_auto); flashBtn.setColorFilter(Color.WHITE) }
        }
    }

    // The rear flash is handled with the torch (one single continuous flash, no pre-flash blink)
    private fun captureFlashMode() = ImageCapture.FLASH_MODE_OFF

    private fun torch(on: Boolean) {
        try { camera?.cameraControl?.enableTorch(on) } catch (_: Exception) {}
    }

    private fun isDark(): Boolean =
        synchronized(lock) { buffer.lastOrNull()?.luma ?: 255 } < 70

    private fun cycleFlash() {
        if (busy) return
        var next = (flashState + 1) % 3
        if (facingFront && next == 0) next = 1   // front camera: only On / Off
        flashState = next
        imageCapture?.flashMode = captureFlashMode()
        updateFlashUi()
    }

    // Front camera "flash": light up the screen border at max brightness
    private fun startScreenFlash() {
        val lp = window.attributes
        prevBrightness = lp.screenBrightness
        lp.screenBrightness = 1f
        window.attributes = lp
        flashOverlay.alpha = 0f
        flashOverlay.visibility = View.VISIBLE
        flashOverlay.animate().alpha(1f).setDuration(150).start()
    }

    private fun endScreenFlash() {
        if (flashOverlay.visibility != View.VISIBLE) return
        flashOverlay.animate().alpha(0f).setDuration(200)
            .withEndAction { flashOverlay.visibility = View.GONE }.start()
        val lp = window.attributes
        lp.screenBrightness = prevBrightness
        window.attributes = lp
    }

    // ---------- Lens / flip ----------

    private fun fadeBackIn() {
        flipping = false
        flipCover.animate().cancel()
        flipCover.animate().alpha(0f).setDuration(280).start()
    }

    private fun flipCamera() {
        if (busy || flipping) return
        flipping = true
        facingFront = !facingFront
        ultraActive = false
        lens = 1
        pinchRatio = null
        if (facingFront && flashState == 0) flashState = 2
        updateFlashUi()
        zoomPill.visibility = if (facingFront) View.GONE else View.VISIBLE
        updateZoomUi()
        // fade to black, switch camera, fade back in when the new image streams
        flipCover.animate().cancel()
        flipCover.animate().alpha(1f).setDuration(150).withEndAction { bindCamera() }.start()
        uiHandler.postDelayed({ if (flipping) fadeBackIn() }, 1500)
    }

    // Tap to focus (+ exposure) with a yellow square, like iPhone
    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            cam.cameraControl.startFocusAndMetering(
                FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                    .setAutoCancelDuration(4, TimeUnit.SECONDS).build()
            )
        } catch (_: Exception) {
        }
        val r = focusRing
        uiHandler.removeCallbacks(hideRing)
        r.animate().cancel()
        r.x = x - r.width / 2f
        r.y = y - r.height / 2f
        r.scaleX = 1.4f; r.scaleY = 1.4f; r.alpha = 1f
        r.visibility = View.VISIBLE
        r.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
        uiHandler.postDelayed(hideRing, 1000)
    }

    private fun pinchZoom(f: Float) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val r = (zs.zoomRatio * f).coerceIn(zs.minZoomRatio, min(zs.maxZoomRatio, 4f))
        cam.cameraControl.setZoomRatio(r)
        if (!facingFront) {
            pinchRatio = if (ultraActive) r * 0.6f else r
            lens = if (ultraActive) 0 else if (r < 1.5f) 1 else 2
            updateZoomUi()
        }
    }

    private fun updateZoomUi() {
        val names = listOf("0.6", "1", "2")
        zoomViews.forEachIndexed { i, tv ->
            val sel = i == lens
            val pr = pinchRatio
            tv.text = if (sel && pr != null) String.format(Locale.US, "%.1f×", pr)
                      else if (sel) names[i] + "×" else names[i]
            tv.setTextColor(if (sel) YELLOW else Color.WHITE)
            tv.textSize = if (sel) 15f else 13f
        }
    }

    private fun selectLens(l: Int) {
        if (busy || facingFront) return
        val minZ = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
        if (l == 0 && !(minZ <= 0.7f) && ultraId == null) {
            Toast.makeText(this, "Tu teléfono no entrega el ultra gran angular a otras apps", Toast.LENGTH_LONG).show()
            return
        }
        lens = l
        pinchRatio = null
        val needUltra = l == 0 && !(minZ <= 0.7f) && ultraId != null
        if (needUltra != ultraActive) {
            ultraActive = needUltra
            bindCamera()
        } else {
            applyZoom()
        }
        updateZoomUi()
    }

    private fun applyZoom() {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value
        val minZ = zs?.minZoomRatio ?: 1f
        val maxZ = zs?.maxZoomRatio ?: 1f
        val target = if (facingFront) 1f else when (lens) {
            0 -> if (ultraActive) 1f else 0.6f
            2 -> 2f
            else -> 1f
        }
        cam.cameraControl.setZoomRatio(target.coerceIn(minZ, maxZ))
    }

    private fun startAll() {
        startCamera()
        startAudio()
    }

    override fun onDestroy() {
        audioRunning = false
        analysisExecutor.execute { releaseEncoder() }
        super.onDestroy()
    }

    // ---------- Audio (rolling PCM buffer) ----------

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        if (audioRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }
        audioRunning = true
        Thread {
            rec.startRecording()
            val tmp = ByteArray(2048)
            while (audioRunning) {
                val n = rec.read(tmp, 0, tmp.size)
                if (n > 0) {
                    val now = SystemClock.elapsedRealtimeNanos()
                    val durNs = (n / 2) * 1_000_000_000L / SAMPLE_RATE
                    val chunk = AudioChunk(tmp.copyOf(n), now - durNs)
                    synchronized(lock) {
                        audioBuffer.addLast(chunk)
                        if (!capturing) {
                            val limit = now - PRE_NS - 300_000_000L
                            while (audioBuffer.size > 1 && audioBuffer.first().startNs < limit) audioBuffer.removeFirst()
                        }
                    }
                }
            }
            rec.stop(); rec.release()
        }.start()
    }

    // ---------- Camera ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            detectUltra()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    // Looks for a separate back camera with a much shorter focal length (ultra-wide)
    @OptIn(ExperimentalCamera2Interop::class)
    private fun detectUltra() {
        val provider = cameraProvider ?: return
        try {
            val infos = provider.availableCameraInfos
            val main = CameraSelector.DEFAULT_BACK_CAMERA.filter(infos).firstOrNull() ?: return
            val mainId = Camera2CameraInfo.from(main).cameraId
            fun focal(i: CameraInfo): Float =
                Camera2CameraInfo.from(i)
                    .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                    ?.minOrNull() ?: 0f
            val mainFocal = focal(main)
            val ultra = infos
                .filter { it.lensFacing == CameraSelector.LENS_FACING_BACK && Camera2CameraInfo.from(it).cameraId != mainId }
                .filter { val f = focal(it); f > 0f && f < mainFocal * 0.75f }
                .minByOrNull { focal(it) }
            ultraId = ultra?.let { Camera2CameraInfo.from(it).cameraId }
        } catch (_: Exception) {
        }
    }

    // Picks an AE range up to 60 fps (prefers 30-60 so low light can still expose well)
    @OptIn(ExperimentalCamera2Interop::class)
    private fun pickFpsRange(selector: CameraSelector, provider: ProcessCameraProvider): android.util.Range<Int>? = try {
        val info = selector.filter(provider.availableCameraInfos).firstOrNull()
        val ranges = info?.let {
            Camera2CameraInfo.from(it).getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
        }?.filter { it.upper == VIDEO_FPS }.orEmpty()
        ranges.firstOrNull { it.lower == 30 } ?: ranges.minByOrNull { it.lower }
    } catch (_: Exception) { null }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun bindCamera() {
        val provider = cameraProvider ?: return
        val wantedId = ultraId
        val selector = when {
            facingFront -> CameraSelector.DEFAULT_FRONT_CAMERA
            ultraActive && wantedId != null -> CameraSelector.Builder()
                .addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == wantedId } }
                .build()
            else -> CameraSelector.DEFAULT_BACK_CAMERA
        }

        // Optical image stabilization (if the lens has it)
        val ois = try {
            selector.filter(provider.availableCameraInfos).firstOrNull()?.let {
                Camera2CameraInfo.from(it)
                    .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            }?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        } catch (_: Exception) { false }

        val fps = pickFpsRange(selector, provider)
        fun <T> applyOpts(b: ExtendableBuilder<T>) {
            val e = Camera2Interop.Extender(b)
            if (ois) e.setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            if (fps != null) e.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fps)
        }

        val pb = Preview.Builder()
        applyOpts(pb)
        val preview = pb.build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

        val photoSelector = if (hiRes) ResolutionSelector.Builder()
            .setAspectRatioStrategy(androidx.camera.core.resolutionselector.AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
            .build()
        else ResolutionSelector.Builder()
            .setAspectRatioStrategy(androidx.camera.core.resolutionselector.AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy(Size(4608, 3456), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
            .build()
        val icb = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setJpegQuality(95)
            .setResolutionSelector(photoSelector)
            .setFlashMode(captureFlashMode())
        applyOpts(icb)
        imageCapture = icb.build()

        val ab = ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(960, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    ).build()
            )
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        applyOpts(ab)
        val analysis = ab.build()
        analysis.setAnalyzer(analysisExecutor) { img -> onFrame(img) }

        synchronized(lock) { buffer.clear(); videoBuf.clear() }
        analysisExecutor.execute { releaseEncoder() }
        try {
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, selector, preview, imageCapture, analysis)
            applyZoom()
            val minZ = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
            zoomViews[0].visibility = if (minZ <= 0.7f || ultraId != null) View.VISIBLE else View.GONE
        } catch (e: Exception) {
            if (ultraActive) {
                ultraActive = false
                lens = 1
                updateZoomUi()
                Toast.makeText(this, "El ultra gran angular no se puede usar con Live en este teléfono", Toast.LENGTH_LONG).show()
                bindCamera()
            } else {
                Toast.makeText(this, "Error de cámara: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- Rolling frame buffer (pre-roll), encoded in real time ----------

    private fun ensureEncoder(w: Int, h: Int): MediaCodec {
        enc?.let { if (encW == w && encH == h) return it }
        releaseEncoder()
        val format = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS)
            setInteger(MediaFormat.KEY_PRIORITY, 0)
            setInteger(MediaFormat.KEY_OPERATING_RATE, VIDEO_FPS)
            setFloat(MediaFormat.KEY_I_FRAME_INTERVAL, 0.5f)
            setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            if (Build.VERSION.SDK_INT >= 29) setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
            if (Build.VERSION.SDK_INT >= 30) setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
        }
        val c = MediaCodec.createEncoderByType("video/avc")
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        c.start()
        enc = c; encW = w; encH = h; encFormat = null
        return c
    }

    private fun releaseEncoder() {
        try { enc?.stop() } catch (_: Exception) {}
        try { enc?.release() } catch (_: Exception) {}
        enc = null; encFormat = null
    }

    private fun drainEncoder(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (true) {
            val o = c.dequeueOutputBuffer(info, 0)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                encFormat = c.outputFormat
            } else if (o >= 0) {
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (info.size > 0 && !isConfig) {
                    val data = c.getOutputBuffer(o)!!
                    val bytes = ByteArray(info.size)
                    data.position(info.offset); data.limit(info.offset + info.size)
                    data.get(bytes)
                    val smp = Sample(bytes, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME)
                    synchronized(lock) { videoBuf.addLast(smp) }
                }
                c.releaseOutputBuffer(o, false)
            } else break
        }
    }

    // Drops encoded samples older than the last key frame that is still before the cutoff
    private fun trimVideo(cutoffNs: Long) {
        var k = -1
        var i = 0
        for (smp in videoBuf) {
            if (smp.pts * 1000 > cutoffNs) break
            if (smp.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0) k = i
            i++
        }
        repeat(maxOf(k, 0)) { videoBuf.removeFirst() }
    }

    private fun onFrame(img: ImageProxy) {
        val ts = img.imageInfo.timestamp
        val w = img.width
        val h = img.height
        val rot = img.imageInfo.rotationDegrees
        var luma = 0
        try {
            val c = ensureEncoder(w, h)
            val i = c.dequeueInputBuffer(0)
            if (i >= 0) {
                val dst = c.getInputImage(i)!!
                copyPlane(img.planes[0], dst.planes[0], w, h)
                copyPlane(img.planes[1], dst.planes[1], w / 2, h / 2)
                copyPlane(img.planes[2], dst.planes[2], w / 2, h / 2)
                c.queueInputBuffer(i, 0, w * h * 3 / 2, ts / 1000, 0)
            }
            luma = lumaOf(img.planes[0], w, h)
            drainEncoder(c)
        } catch (e: Exception) {
            releaseEncoder()
        }
        val frame = Frame(ts, SystemClock.elapsedRealtimeNanos(), luma)
        img.close()

        var snapshot: List<Frame>? = null
        var videoSnap: List<Sample> = emptyList()
        var audioSnap: List<AudioChunk> = emptyList()
        var shotData: List<Pair<Long, ByteArray>> = emptyList()
        synchronized(lock) {
            buffer.addLast(frame)
            val ready = shots.filter { it.jpeg != null }
            if (!capturing || ready.isEmpty()) {
                val keep = if (capturing) PRE_NS + 2_000_000_000L else PRE_NS
                while (buffer.size > 1 && ts - buffer.first().ts > keep) buffer.removeFirst()
                trimVideo(ts - keep)
            } else if (pendingPhotos == 0 && ts - ready.maxOf { it.ts } >= POST_NS) {
                // burst finished: one long clip for all the photos of the burst
                capturing = false
                shotData = ready.map { Pair(it.ts, it.jpeg!!) }
                shots.clear()
                snapshot = ArrayList(buffer)
                videoSnap = ArrayList(videoBuf)
                audioSnap = ArrayList(audioBuffer)
                while (buffer.size > 1 && ts - buffer.first().ts > PRE_NS) buffer.removeFirst()
                trimVideo(ts - PRE_NS)
                val limit = frame.arrival - PRE_NS - 300_000_000L
                while (audioBuffer.size > 1 && audioBuffer.first().startNs < limit) audioBuffer.removeFirst()
            }
        }
        val snap = snapshot
        val vid = videoSnap
        val aud = audioSnap
        val sd = shotData
        val fmt = encFormat
        if (snap != null && sd.isNotEmpty()) {
            // Free the UI right away; muxing/saving continues in the background
            runOnUiThread { showLive(false); busy = false; endScreenFlash() }
            encodeExecutor.execute { finishSession(snap, vid, fmt, aud, rot, sd) }
        }
    }

    // Average brightness (sampled) – used to find the flash frame
    private fun lumaOf(p: ImageProxy.PlaneProxy, w: Int, h: Int): Int {
        val buf = p.buffer
        val rs = p.rowStride
        var sum = 0L
        var n = 0
        var r = 0
        while (r < h) {
            var c = 0
            while (c < w) { sum += buf.get(r * rs + c).toInt() and 0xFF; n++; c += 8 }
            r += 8
        }
        return if (n == 0) 0 else (sum / n).toInt()
    }

    // Key frame: with flash, the brightest frame near the shot; otherwise the shot itself
    private fun pickKeyTs(all: List<Frame>, shotTs: Long): Long {
        val win = all.filter { abs(it.ts - shotTs) <= 1_000_000_000L }
        if (win.size < 5) return shotTs
        val peak = win.maxOf { it.luma }
        val median = win.map { it.luma }.sorted()[win.size / 2]
        if (peak < median * 1.25f + 8f) return shotTs
        return win.filter { it.luma >= peak * 0.92f }.minByOrNull { abs(it.ts - shotTs) }?.ts ?: shotTs
    }

    private fun copyPlane(src: ImageProxy.PlaneProxy, dst: Image.Plane, cw: Int, ch: Int) {
        val sb = src.buffer
        val srs = src.rowStride
        val sps = src.pixelStride
        val db = dst.buffer
        val drs = dst.rowStride
        val dps = dst.pixelStride
        for (r in 0 until ch) {
            if (sps == 1 && dps == 1) {
                val d = sb.duplicate()
                d.position(r * srs); d.limit(r * srs + cw)
                db.position(r * drs)
                db.put(d)
            } else {
                for (c in 0 until cw) db.put(r * drs + c * dps, sb.get(r * srs + c * sps))
            }
        }
    }

    // ---------- Shutter (burst friendly) ----------

    private fun idle(): Boolean = synchronized(lock) { pendingPhotos == 0 }

    private fun onShutter() {
        val now = SystemClock.uptimeMillis()
        if (imageCapture == null || now - lastShutterMs < SHUTTER_COOLDOWN_MS) return
        synchronized(lock) {
            if (buffer.isEmpty() || pendingPhotos >= MAX_PENDING) return
            if (capturing) {
                if (shots.size >= MAX_BURST) return
                val firstTs = shots.firstOrNull { it.jpeg != null }?.ts ?: 0L
                // very long burst: wait until it is saved (memory limit)
                if (firstTs != 0L && buffer.last().ts - firstTs >= MAX_JOIN_NS) return
            } else {
                capturing = true
                shots.clear()
            }
            pendingPhotos++
        }
        lastShutterMs = now
        busy = true
        blink()
        showLive(true)
        val needTorch = !facingFront && (flashState == 1 || (flashState == 0 && isDark())) &&
            camera?.cameraInfo?.hasFlashUnit() == true
        if (facingFront && flashState == 1) {
            if (flashOverlay.visibility == View.VISIBLE) doCapture()
            else { startScreenFlash(); uiHandler.postDelayed({ doCapture() }, 350) }
        } else if (needTorch) {
            if (torchOn) doCapture()
            else {
                torch(true); torchOn = true
                uiHandler.postDelayed({ doCapture() }, 450)   // let exposure settle with the light on
            }
        } else {
            doCapture()
        }
    }

    // iPhone-style flash on every tap + little button press
    private fun blink() {
        shotFlash.animate().cancel()
        shotFlash.alpha = 0.85f
        shotFlash.animate().alpha(0f).setDuration(170).start()
        shutterBtn.animate().cancel()
        shutterBtn.scaleX = 0.88f; shutterBtn.scaleY = 0.88f
        shutterBtn.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
    }

    private fun doCapture() {
        val shot = Shot()
        synchronized(lock) { shots.add(shot) }
        imageCapture!!.takePicture(ioExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    // Exact sensor timestamp of the real photo
                    val ts = image.imageInfo.timestamp
                    val rot = image.imageInfo.rotationDegrees
                    val b = image.planes[0].buffer
                    val raw = ByteArray(b.remaining())
                    b.get(raw)
                    val fixed = withOrientation(raw, rot)
                    synchronized(lock) { shot.jpeg = fixed; shot.ts = ts; pendingPhotos-- }
                    runOnUiThread {
                        // keep lights on a bit after the last shot, unless another shot is coming
                        uiHandler.postDelayed({ if (idle()) endScreenFlash() }, SCREEN_FLASH_HOLD_MS)
                        uiHandler.postDelayed({ if (idle() && torchOn) { torch(false); torchOn = false } }, 250)
                    }
                } catch (e: Exception) {
                    failShot(shot, e.message)
                } finally {
                    image.close()
                }
            }

            override fun onError(e: ImageCaptureException) { failShot(shot, e.message) }
        })
    }

    private fun failShot(shot: Shot, msg: String?) {
        var ended = false
        synchronized(lock) {
            shots.remove(shot)
            pendingPhotos = maxOf(0, pendingPhotos - 1)
            if (shots.isEmpty() && pendingPhotos == 0) { capturing = false; ended = true }
        }
        runOnUiThread {
            if (ended) { showLive(false); busy = false; endScreenFlash(); torch(false); torchOn = false }
            Toast.makeText(this, "Error: $msg", Toast.LENGTH_LONG).show()
        }
    }

    private fun withOrientation(raw: ByteArray, rot: Int): ByteArray {
        val f = File(cacheDir, "p_${System.nanoTime()}.jpg")
        try {
            f.writeBytes(raw)
            val ex = ExifInterface(f.path)
            val o = when (rot) {
                90 -> ExifInterface.ORIENTATION_ROTATE_90
                180 -> ExifInterface.ORIENTATION_ROTATE_180
                270 -> ExifInterface.ORIENTATION_ROTATE_270
                else -> ExifInterface.ORIENTATION_NORMAL
            }
            ex.setAttribute(ExifInterface.TAG_ORIENTATION, o.toString())
            ex.saveAttributes()
            return f.readBytes()
        } finally {
            f.delete()
        }
    }

    // iPhone-style "LIVE" pill: fades in while capturing, fades out when done
    private fun showLive(on: Boolean) {
        status.animate().cancel()
        if (on) {
            status.visibility = View.VISIBLE
            status.animate().alpha(1f).setDuration(150).start()
        } else {
            status.animate().alpha(0f).setDuration(300)
                .withEndAction { status.visibility = View.INVISIBLE }.start()
        }
    }

    // ---------- Encode + pack Motion Photo ----------

    private fun finishSession(
        meta: List<Frame>, vids: List<Sample>, vfmt: MediaFormat?, audio: List<AudioChunk>, rot: Int,
        sd: List<Pair<Long, ByteArray>>
    ) {
        try {
            if (vfmt == null || vids.isEmpty() || meta.isEmpty()) throw IllegalStateException("Sin video")
            val keys = sd.map { pickKeyTs(meta, it.first) }
            val KEY = MediaCodec.BUFFER_FLAG_KEY_FRAME
            fun startIdx(limitNs: Long): Int {
                var st = 0
                for ((i, smp) in vids.withIndex()) {
                    if (smp.pts * 1000 > limitNs) break
                    if (smp.flags and KEY != 0) st = i
                }
                while (st < vids.size - 1 && vids[st].flags and KEY == 0) st++
                return st
            }
            fun buildClip(sub: List<Sample>): ByteArray {
                val t = sub.first().pts
                val fa = meta.firstOrNull { it.ts >= t * 1000 }?.arrival ?: meta.first().arrival
                val f = File(cacheDir, "clip_${System.nanoTime()}.mp4")
                mux(sub, vfmt, t, audio, fa, rot, f)
                val bytes = f.readBytes()
                f.delete()
                return bytes
            }
            val lo = minOf(keys.minOrNull()!!, sd.minOf { it.first })
            val vs = vids.subList(startIdx(lo - PRE_NS), vids.size)
            val n = sd.size
            val burstId = System.currentTimeMillis().toString()
            // Long Live: stored ONLY inside the app (not in the phone gallery)
            if (n > 1) {
                try {
                    val lf = Media.longFile(this, burstId)
                    lf.parentFile?.mkdirs()
                    val big = File(cacheDir, "long_${burstId}.mp4")
                    val t = vs.first().pts
                    val fa = meta.firstOrNull { it.ts >= t * 1000 }?.arrival ?: meta.first().arrival
                    mux(vs, vfmt, t, audio, fa, rot, big)
                    big.copyTo(lf, true); big.delete()
                } catch (_: Exception) {}
            }
            var coverUri: Uri? = null
            // Each photo keeps only its own normal-length Live (1.5 s before + 1.5 s after), 60 fps.
            // Saved from last to first so photo 1 ends up on top in the gallery.
            for (i in n - 1 downTo 0) {
                val s0 = startIdx(minOf(keys[i], sd[i].first) - PRE_NS)
                val endNs = maxOf(keys[i], sd[i].first) + POST_NS
                var e = s0
                while (e + 1 < vids.size && vids[e + 1].pts * 1000 <= endNs) e++
                val sub = vids.subList(s0, e + 1)
                val clip = buildClip(sub)
                val presUs = maxOf(0L, keys[i] / 1000 - sub.first().pts)
                val u = save(packMotionPhoto(sd[i].second, clip, presUs, 0L, n, burstId, i), i)
                if (i == 0) coverUri = u
            }
            coverUri?.let { u -> runOnUiThread { loadThumb(u) } }
            if (SHOW_FPS_TOAST) {
                val t0 = vs.first().pts
                val durUs = vs.last().pts - t0
                val fps = if (durUs > 0) (vs.size - 1) * 1_000_000f / durUs else 0f
                runOnUiThread {
                    Toast.makeText(this, String.format(Locale.US, "Live %.1f s · %.0f fps", durUs / 1e6f, fps),
                        Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun mux(
        vs: List<Sample>, vfmt: MediaFormat, t0: Long, audio: List<AudioChunk>, firstArrival: Long,
        rotation: Int, out: File
    ) {
        val aud = encodeAudio(audio, firstArrival)

        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer.setOrientationHint(rotation)
        val vt = muxer.addTrack(vfmt)
        val at = if (aud != null) muxer.addTrack(aud.first) else -1
        muxer.start()

        val endRel = vs.last().pts - t0
        val asamples = (aud?.second ?: emptyList()).filter { it.pts <= endRel }
        val info = MediaCodec.BufferInfo()
        var vi = 0
        var ai = 0
        while (vi < vs.size || ai < asamples.size) {
            val useV = ai >= asamples.size || (vi < vs.size && vs[vi].pts - t0 <= asamples[ai].pts)
            val smp = if (useV) vs[vi++] else asamples[ai++]
            info.set(0, smp.data.size, if (useV) smp.pts - t0 else smp.pts, smp.flags)
            muxer.writeSampleData(if (useV) vt else at, ByteBuffer.wrap(smp.data), info)
        }
        muxer.stop(); muxer.release()
    }

    private fun encodeAudio(chunks: List<AudioChunk>, firstArrival: Long): Pair<MediaFormat, List<Sample>>? {
        val relevant = chunks.filter {
            it.startNs + (it.data.size / 2) * 1_000_000_000L / SAMPLE_RATE >= firstArrival
        }
        if (relevant.isEmpty()) return null
        val base = maxOf(0L, (relevant.first().startNs - firstArrival) / 1000) + AUDIO_OFFSET_US
        val pcmStream = ByteArrayOutputStream()
        relevant.forEach { pcmStream.write(it.data) }
        val pcm = pcmStream.toByteArray()

        val format = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType("audio/mp4a-latm")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val samples = ArrayList<Sample>()
        var outFormat: MediaFormat? = null
        val info = MediaCodec.BufferInfo()
        var offset = 0
        var inputDone = false
        var outputDone = false
        while (!outputDone) {
            if (!inputDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val pts = base + (offset / 2) * 1_000_000L / SAMPLE_RATE
                    if (offset < pcm.size) {
                        val buf = codec.getInputBuffer(i)!!
                        buf.clear()
                        val n = minOf(buf.capacity(), pcm.size - offset)
                        buf.put(pcm, offset, n)
                        codec.queueInputBuffer(i, 0, n, pts, 0)
                        offset += n
                    } else {
                        codec.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                outFormat = codec.outputFormat
            } else if (o >= 0) {
                val data = codec.getOutputBuffer(o)!!
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (info.size > 0 && !isConfig) {
                    val bytes = ByteArray(info.size)
                    data.position(info.offset); data.limit(info.offset + info.size)
                    data.get(bytes)
                    samples.add(Sample(bytes, info.presentationTimeUs, 0))
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        codec.stop(); codec.release()
        return Pair(outFormat ?: return null, samples)
    }

    private fun packMotionPhoto(jpeg: ByteArray, mp4: ByteArray, presUs: Long, startUs: Long, burst: Int, burstId: String, idx: Int): ByteArray {
        val xmp = """
            <x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:GCamera="http://ns.google.com/photos/1.0/camera/" xmlns:Container="http://ns.google.com/photos/1.0/container/" xmlns:Item="http://ns.google.com/photos/1.0/container/item/" GCamera:MotionPhoto="1" GCamera:MotionPhotoVersion="1" GCamera:MotionPhotoPresentationTimestampUs="$presUs" xmlns:LiveCam="http://livecam.app/1.0/" LiveCam:StartUs="$startUs" LiveCam:Burst="$burst" LiveCam:BurstId="$burstId" LiveCam:BurstIdx="$idx"><Container:Directory><rdf:Seq><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/></rdf:li><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/></rdf:li></rdf:Seq></Container:Directory></rdf:Description></rdf:RDF></x:xmpmeta>
        """.trimIndent()
        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val xmpBytes = xmp.toByteArray(Charsets.UTF_8)
        val segLen = 2 + header.size + xmpBytes.size

        // Insert after the existing APP0/APP1 (EXIF) segments
        var pos = 2
        while (pos + 4 < jpeg.size && (jpeg[pos].toInt() and 0xFF) == 0xFF) {
            val m = jpeg[pos + 1].toInt() and 0xFF
            if (m != 0xE0 && m != 0xE1) break
            val len = ((jpeg[pos + 2].toInt() and 0xFF) shl 8) or (jpeg[pos + 3].toInt() and 0xFF)
            pos += 2 + len
        }
        val out = ByteArrayOutputStream(jpeg.size + mp4.size + segLen + 4)
        out.write(jpeg, 0, pos)
        out.write(0xFF); out.write(0xE1)
        out.write(segLen shr 8); out.write(segLen and 0xFF)
        out.write(header); out.write(xmpBytes)
        out.write(jpeg, pos, jpeg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }

    private fun save(bytes: ByteArray, idx: Int = 0): Uri {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_$name${if (idx > 0) "_$idx" else ""}.MP")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiveCam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo guardar")
        contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        return uri
    }
}

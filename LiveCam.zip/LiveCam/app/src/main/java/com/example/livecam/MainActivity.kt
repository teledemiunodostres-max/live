package com.example.livecam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.*
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Frame(val data: ByteArray, val ts: Long, val arrival: Long)
class AudioChunk(val data: ByteArray, val startNs: Long)
class Sample(val data: ByteArray, val pts: Long, val flags: Int)

class MainActivity : AppCompatActivity() {

    companion object {
        const val PRE_NS = 1_500_000_000L   // 1.5 s before the tap
        const val POST_NS = 1_500_000_000L  // 1.5 s after the tap
        const val SAMPLE_RATE = 44100
        const val AUDIO_OFFSET_US = 0L      // ajusta si el audio sale adelantado/atrasado
    }

    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var shutter: Button
    private var imageCapture: ImageCapture? = null

    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val encodeExecutor = Executors.newSingleThreadExecutor()

    private val lock = Any()
    private val buffer = ArrayDeque<Frame>()
    private val audioBuffer = ArrayDeque<AudioChunk>()
    @Volatile private var audioRunning = false
    private var capturing = false
    private var shutterTs = 0L
    private var photoLatch = CountDownLatch(1)
    private var photoFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        status = findViewById(R.id.status)
        shutter = findViewById(R.id.shutter)
        shutter.setOnClickListener { onShutter() }

        if (hasPermission()) startAll()
        else ActivityCompat.requestPermissions(
            this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 10
        )
    }

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPermission()) startAll() else finish()
    }

    private fun startAll() {
        startCamera()
        startAudio()
    }

    override fun onDestroy() {
        audioRunning = false
        super.onDestroy()
    }

    // ---------- Audio (rolling PCM buffer) ----------

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        if (audioRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }
        audioRunning = true
        Thread {
            rec.startRecording()
            val tmp = ByteArray(2048)
            while (audioRunning) {
                val n = rec.read(tmp, 0, tmp.size)
                if (n > 0) {
                    val now = SystemClock.elapsedRealtimeNanos()
                    val durNs = (n / 2) * 1_000_000_000L / SAMPLE_RATE
                    val chunk = AudioChunk(tmp.copyOf(n), now - durNs)
                    synchronized(lock) {
                        audioBuffer.addLast(chunk)
                        if (!capturing) {
                            val limit = now - PRE_NS - 300_000_000L
                            while (audioBuffer.size > 1 && audioBuffer.first().startNs < limit) audioBuffer.removeFirst()
                        }
                    }
                }
            }
            rec.stop(); rec.release()
        }.start()
    }

    // ---------- Camera ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val photoSelector = ResolutionSelector.Builder()
                .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
                .build()
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(photoSelector)
                .build()

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setResolutionStrategy(
                            ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        ).build()
                )
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(analysisExecutor) { img -> onFrame(img) }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analysis)
            } catch (e: Exception) {
                Toast.makeText(this, "Error de cámara: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------- Rolling frame buffer (pre-roll) ----------

    private fun onFrame(img: ImageProxy) {
        val ts = img.imageInfo.timestamp
        val w = img.width
        val h = img.height
        val rot = img.imageInfo.rotationDegrees
        val frame = Frame(toI420(img), ts, SystemClock.elapsedRealtimeNanos())
        img.close()

        var snapshot: List<Frame>? = null
        var audioSnap: List<AudioChunk> = emptyList()
        synchronized(lock) {
            buffer.addLast(frame)
            if (!capturing) {
                while (buffer.size > 1 && ts - buffer.first().ts > PRE_NS) buffer.removeFirst()
            } else if (ts - shutterTs >= POST_NS) {
                capturing = false
                snapshot = ArrayList(buffer)
                audioSnap = ArrayList(audioBuffer)
                while (buffer.size > 1 && ts - buffer.first().ts > PRE_NS) buffer.removeFirst()
                val limit = frame.arrival - PRE_NS - 300_000_000L
                while (audioBuffer.size > 1 && audioBuffer.first().startNs < limit) audioBuffer.removeFirst()
            }
        }
        snapshot?.let { snap ->
            val latch = photoLatch
            val shotShutterTs = shutterTs
            encodeExecutor.execute { finishShot(snap, audioSnap, w, h, rot, shotShutterTs, latch) }
        }
    }

    private fun toI420(img: ImageProxy): ByteArray {
        val w = img.width
        val h = img.height
        val out = ByteArray(w * h * 3 / 2)
        copyPlane(img.planes[0], w, h, out, 0)
        copyPlane(img.planes[1], w / 2, h / 2, out, w * h)
        copyPlane(img.planes[2], w / 2, h / 2, out, w * h + w * h / 4)
        return out
    }

    private fun copyPlane(p: ImageProxy.PlaneProxy, cw: Int, ch: Int, out: ByteArray, offset: Int) {
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        var o = offset
        for (r in 0 until ch) {
            val rowStart = r * rs
            if (ps == 1) {
                buf.position(rowStart)
                buf.get(out, o, cw)
                o += cw
            } else {
                for (c in 0 until cw) out[o++] = buf.get(rowStart + c * ps)
            }
        }
    }

    // ---------- Shutter ----------

    private fun onShutter() {
        synchronized(lock) {
            if (capturing || buffer.isEmpty()) return
            capturing = true
            shutterTs = buffer.last().ts
            photoLatch = CountDownLatch(1)
        }
        status.text = "● LIVE"
        shutter.isEnabled = false

        val file = File(cacheDir, "photo_${System.currentTimeMillis()}.jpg")
        photoFile = file
        val latch = photoLatch
        imageCapture!!.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) { latch.countDown() }
                override fun onError(e: ImageCaptureException) {
                    photoFile = null
                    latch.countDown()
                }
            })
    }

    // ---------- Encode + pack Motion Photo ----------

    private fun finishShot(
        frames: List<Frame>, audio: List<AudioChunk>, w: Int, h: Int, rot: Int,
        shotTs: Long, latch: CountDownLatch
    ) {
        try {
            val mp4 = File(cacheDir, "clip_${System.currentTimeMillis()}.mp4")
            mux(frames, audio, w, h, rot, mp4)
            latch.await(10, TimeUnit.SECONDS)
            val photo = photoFile ?: throw IllegalStateException("No se pudo tomar la foto")
            val presUs = (shotTs - frames.first().ts) / 1000
            val packed = packMotionPhoto(photo.readBytes(), mp4.readBytes(), presUs)
            save(packed)
            photo.delete(); mp4.delete()
            runOnUiThread { Toast.makeText(this, "Live guardada", Toast.LENGTH_SHORT).show() }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        } finally {
            runOnUiThread { status.text = ""; shutter.isEnabled = true }
        }
    }

    private fun mux(frames: List<Frame>, audio: List<AudioChunk>, w: Int, h: Int, rotation: Int, out: File) {
        val video = encodeVideo(frames, w, h)
        val aud = encodeAudio(audio, frames.first().arrival)

        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer.setOrientationHint(rotation)
        val vt = muxer.addTrack(video.first)
        val at = if (aud != null) muxer.addTrack(aud.first) else -1
        muxer.start()

        val vs = video.second
        val asamples = aud?.second ?: emptyList()
        val info = MediaCodec.BufferInfo()
        var vi = 0
        var ai = 0
        while (vi < vs.size || ai < asamples.size) {
            val useV = ai >= asamples.size || (vi < vs.size && vs[vi].pts <= asamples[ai].pts)
            val s = if (useV) vs[vi++] else asamples[ai++]
            info.set(0, s.data.size, s.pts, s.flags)
            muxer.writeSampleData(if (useV) vt else at, ByteBuffer.wrap(s.data), info)
        }
        muxer.stop(); muxer.release()
    }

    private fun encodeVideo(frames: List<Frame>, w: Int, h: Int): Pair<MediaFormat, List<Sample>> {
        val format = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, 10_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType("video/avc")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val samples = ArrayList<Sample>()
        var outFormat: MediaFormat? = null
        val info = MediaCodec.BufferInfo()
        val t0 = frames.first().ts
        var idx = 0
        var inputDone = false
        var outputDone = false
        while (!outputDone) {
            if (!inputDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    if (idx < frames.size) {
                        val f = frames[idx]
                        fillImage(codec.getInputImage(i)!!, f.data, w, h)
                        codec.queueInputBuffer(i, 0, w * h * 3 / 2, (f.ts - t0) / 1000, 0)
                        idx++
                    } else {
                        codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                outFormat = codec.outputFormat
            } else if (o >= 0) {
                val data = codec.getOutputBuffer(o)!!
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (info.size > 0 && !isConfig) {
                    val bytes = ByteArray(info.size)
                    data.position(info.offset); data.limit(info.offset + info.size)
                    data.get(bytes)
                    samples.add(Sample(bytes, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME))
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        codec.stop(); codec.release()
        return Pair(outFormat ?: throw IllegalStateException("Sin formato de video"), samples)
    }

    private fun encodeAudio(chunks: List<AudioChunk>, firstArrival: Long): Pair<MediaFormat, List<Sample>>? {
        val relevant = chunks.filter {
            it.startNs + (it.data.size / 2) * 1_000_000_000L / SAMPLE_RATE >= firstArrival
        }
        if (relevant.isEmpty()) return null
        val base = maxOf(0L, (relevant.first().startNs - firstArrival) / 1000) + AUDIO_OFFSET_US
        val pcmStream = ByteArrayOutputStream()
        relevant.forEach { pcmStream.write(it.data) }
        val pcm = pcmStream.toByteArray()

        val format = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType("audio/mp4a-latm")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val samples = ArrayList<Sample>()
        var outFormat: MediaFormat? = null
        val info = MediaCodec.BufferInfo()
        var offset = 0
        var inputDone = false
        var outputDone = false
        while (!outputDone) {
            if (!inputDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val pts = base + (offset / 2) * 1_000_000L / SAMPLE_RATE
                    if (offset < pcm.size) {
                        val buf = codec.getInputBuffer(i)!!
                        buf.clear()
                        val n = minOf(buf.capacity(), pcm.size - offset)
                        buf.put(pcm, offset, n)
                        codec.queueInputBuffer(i, 0, n, pts, 0)
                        offset += n
                    } else {
                        codec.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                outFormat = codec.outputFormat
            } else if (o >= 0) {
                val data = codec.getOutputBuffer(o)!!
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (info.size > 0 && !isConfig) {
                    val bytes = ByteArray(info.size)
                    data.position(info.offset); data.limit(info.offset + info.size)
                    data.get(bytes)
                    samples.add(Sample(bytes, info.presentationTimeUs, 0))
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        codec.stop(); codec.release()
        return Pair(outFormat ?: return null, samples)
    }

    private fun fillImage(img: Image, src: ByteArray, w: Int, h: Int) {
        val offsets = intArrayOf(0, w * h, w * h + w * h / 4)
        val widths = intArrayOf(w, w / 2, w / 2)
        val heights = intArrayOf(h, h / 2, h / 2)
        for (p in 0 until 3) {
            val plane = img.planes[p]
            val buf = plane.buffer
            val rs = plane.rowStride
            val ps = plane.pixelStride
            for (r in 0 until heights[p]) {
                val srcOff = offsets[p] + r * widths[p]
                if (ps == 1) {
                    buf.position(r * rs)
                    buf.put(src, srcOff, widths[p])
                } else {
                    for (c in 0 until widths[p]) buf.put(r * rs + c * ps, src[srcOff + c])
                }
            }
        }
    }

    private fun packMotionPhoto(jpeg: ByteArray, mp4: ByteArray, presUs: Long): ByteArray {
        val xmp = """
            <x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:GCamera="http://ns.google.com/photos/1.0/camera/" xmlns:Container="http://ns.google.com/photos/1.0/container/" xmlns:Item="http://ns.google.com/photos/1.0/container/item/" GCamera:MotionPhoto="1" GCamera:MotionPhotoVersion="1" GCamera:MotionPhotoPresentationTimestampUs="$presUs"><Container:Directory><rdf:Seq><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/></rdf:li><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/></rdf:li></rdf:Seq></Container:Directory></rdf:Description></rdf:RDF></x:xmpmeta>
        """.trimIndent()
        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val xmpBytes = xmp.toByteArray(Charsets.UTF_8)
        val segLen = 2 + header.size + xmpBytes.size

        // Insert after the existing APP0/APP1 (EXIF) segments
        var pos = 2
        while (pos + 4 < jpeg.size && (jpeg[pos].toInt() and 0xFF) == 0xFF) {
            val m = jpeg[pos + 1].toInt() and 0xFF
            if (m != 0xE0 && m != 0xE1) break
            val len = ((jpeg[pos + 2].toInt() and 0xFF) shl 8) or (jpeg[pos + 3].toInt() and 0xFF)
            pos += 2 + len
        }
        val out = ByteArrayOutputStream(jpeg.size + mp4.size + segLen + 4)
        out.write(jpeg, 0, pos)
        out.write(0xFF); out.write(0xE1)
        out.write(segLen shr 8); out.write(segLen and 0xFF)
        out.write(header); out.write(xmpBytes)
        out.write(jpeg, pos, jpeg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }

    private fun save(bytes: ByteArray) {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_$name.MP")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiveCam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo guardar")
        contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
    }
}

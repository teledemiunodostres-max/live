package com.example.livecam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Frame(val data: ByteArray, val ts: Long, val arrival: Long)
class AudioChunk(val data: ByteArray, val startNs: Long)
class Sample(val data: ByteArray, val pts: Long, val flags: Int)

class MainActivity : AppCompatActivity() {

    companion object {
        const val PRE_NS = 1_500_000_000L   // 1.5 s before the tap
        const val POST_NS = 1_500_000_000L  // 1.5 s after the tap
        const val SAMPLE_RATE = 44100
        const val AUDIO_OFFSET_US = 0L      // ajusta si el audio sale adelantado/atrasado
        val YELLOW = Color.parseColor("#FFD60A")
    }

    private lateinit var previewView: PreviewView
    private lateinit var previewFrame: View
    private lateinit var status: TextView
    private lateinit var flashBtn: ImageView
    private lateinit var thumb: ImageView
    private lateinit var flipBtn: ImageView
    private lateinit var flashOverlay: View
    private lateinit var zoomPill: View
    private lateinit var zoomViews: List<TextView>

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var facingFront = false
    private var lens = 1                 // 0 = 0.6x, 1 = 1x, 2 = 2x
    private var flashState = 0           // 0 auto, 1 on, 2 off
    private var ultraId: String? = null
    private var ultraActive = false
    @Volatile private var busy = false
    private var prevBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
    private val uiHandler = Handler(Looper.getMainLooper())

    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val encodeExecutor = Executors.newSingleThreadExecutor()

    private val lock = Any()
    private val buffer = ArrayDeque<Frame>()
    private val audioBuffer = ArrayDeque<AudioChunk>()
    @Volatile private var audioRunning = false
    private var capturing = false
    private var shutterTs = 0L
    private var photoLatch = CountDownLatch(1)
    private var photoFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        previewFrame = findViewById(R.id.previewFrame)
        status = findViewById(R.id.status)
        flashBtn = findViewById(R.id.flashBtn)
        thumb = findViewById(R.id.thumb)
        flipBtn = findViewById(R.id.flipBtn)
        flashOverlay = findViewById(R.id.flashOverlay)
        zoomPill = findViewById(R.id.zoomPill)
        zoomViews = listOf(R.id.z06, R.id.z1, R.id.z2).map { findViewById<TextView>(it) }
        findViewById<ImageView>(R.id.liveIcon).setColorFilter(YELLOW)

        // 3:4 preview, same as the photo
        previewFrame.post {
            val lp = previewFrame.layoutParams
            lp.height = previewFrame.width * 4 / 3
            previewFrame.layoutParams = lp
        }

        findViewById<View>(R.id.shutter).setOnClickListener { onShutter() }
        flashBtn.setOnClickListener { cycleFlash() }
        flipBtn.setOnClickListener { flipCamera() }
        thumb.setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
        zoomViews.forEachIndexed { i, v -> v.setOnClickListener { selectLens(i) } }
        updateFlashUi()
        updateZoomUi()

        if (hasPermission()) startAll()
        else {
            val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            else perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= 28) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), 10)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshThumb()
    }

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPermission()) { startAll(); refreshThumb() } else finish()
    }

    // ---------- Thumbnail ----------

    private fun refreshThumb() {
        Thread {
            val latest = Media.queryLive(this).firstOrNull()
            if (latest != null) loadThumb(latest)
        }.start()
    }

    private fun loadThumb(uri: Uri) {
        Thread {
            val bmp = Media.decode(this, uri, 8)
            runOnUiThread { if (bmp != null) thumb.setImageBitmap(bmp) }
        }.start()
    }

    // ---------- Flash ----------

    private fun updateFlashUi() {
        when (flashState) {
            1 -> { flashBtn.setImageResource(R.drawable.ic_flash_on); flashBtn.setColorFilter(YELLOW) }
            2 -> { flashBtn.setImageResource(R.drawable.ic_flash_off); flashBtn.setColorFilter(Color.WHITE) }
            else -> { flashBtn.setImageResource(R.drawable.ic_flash_auto); flashBtn.setColorFilter(Color.WHITE) }
        }
    }

    private fun captureFlashMode() = if (facingFront) ImageCapture.FLASH_MODE_OFF else when (flashState) {
        1 -> ImageCapture.FLASH_MODE_ON
        2 -> ImageCapture.FLASH_MODE_OFF
        else -> ImageCapture.FLASH_MODE_AUTO
    }

    private fun cycleFlash() {
        if (busy) return
        var next = (flashState + 1) % 3
        if (facingFront && next == 0) next = 1   // front camera: only On / Off
        flashState = next
        imageCapture?.flashMode = captureFlashMode()
        updateFlashUi()
    }

    // Front camera "flash": light up the screen border at max brightness
    private fun startScreenFlash() {
        val lp = window.attributes
        prevBrightness = lp.screenBrightness
        lp.screenBrightness = 1f
        window.attributes = lp
        flashOverlay.alpha = 0f
        flashOverlay.visibility = View.VISIBLE
        flashOverlay.animate().alpha(1f).setDuration(150).start()
    }

    private fun endScreenFlash() {
        if (flashOverlay.visibility != View.VISIBLE) return
        flashOverlay.animate().alpha(0f).setDuration(200)
            .withEndAction { flashOverlay.visibility = View.GONE }.start()
        val lp = window.attributes
        lp.screenBrightness = prevBrightness
        window.attributes = lp
    }

    // ---------- Lens / flip ----------

    private fun flipCamera() {
        if (busy) return
        facingFront = !facingFront
        ultraActive = false
        lens = 1
        if (facingFront && flashState == 0) flashState = 2
        updateFlashUi()
        zoomPill.visibility = if (facingFront) View.GONE else View.VISIBLE
        bindCamera()
        updateZoomUi()
    }

    private fun updateZoomUi() {
        val names = listOf("0.6", "1", "2")
        zoomViews.forEachIndexed { i, tv ->
            val sel = i == lens
            tv.text = if (sel) names[i] + "×" else names[i]
            tv.setTextColor(if (sel) YELLOW else Color.WHITE)
            tv.textSize = if (sel) 15f else 13f
        }
    }

    private fun selectLens(l: Int) {
        if (busy || facingFront) return
        val minZ = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
        if (l == 0 && !(minZ <= 0.7f) && ultraId == null) {
            Toast.makeText(this, "Tu teléfono no entrega el ultra gran angular a otras apps", Toast.LENGTH_LONG).show()
            return
        }
        lens = l
        val needUltra = l == 0 && !(minZ <= 0.7f) && ultraId != null
        if (needUltra != ultraActive) {
            ultraActive = needUltra
            bindCamera()
        } else {
            applyZoom()
        }
        updateZoomUi()
    }

    private fun applyZoom() {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value
        val minZ = zs?.minZoomRatio ?: 1f
        val maxZ = zs?.maxZoomRatio ?: 1f
        val target = if (facingFront) 1f else when (lens) {
            0 -> if (ultraActive) 1f else 0.6f
            2 -> 2f
            else -> 1f
        }
        cam.cameraControl.setZoomRatio(target.coerceIn(minZ, maxZ))
    }

    private fun startAll() {
        startCamera()
        startAudio()
    }

    override fun onDestroy() {
        audioRunning = false
        super.onDestroy()
    }

    // ---------- Audio (rolling PCM buffer) ----------

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        if (audioRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }
        audioRunning = true
        Thread {
            rec.startRecording()
            val tmp = ByteArray(2048)
            while (audioRunning) {
                val n = rec.read(tmp, 0, tmp.size)
                if (n > 0) {
                    val now = SystemClock.elapsedRealtimeNanos()
                    val durNs = (n / 2) * 1_000_000_000L / SAMPLE_RATE
                    val chunk = AudioChunk(tmp.copyOf(n), now - durNs)
                    synchronized(lock) {
                        audioBuffer.addLast(chunk)
                        if (!capturing) {
                            val limit = now - PRE_NS - 300_000_000L
                            while (audioBuffer.size > 1 && audioBuffer.first().startNs < limit) audioBuffer.removeFirst()
                        }
                    }
                }
            }
            rec.stop(); rec.release()
        }.start()
    }

    // ---------- Camera ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            detectUltra()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    // Looks for a separate back camera with a much shorter focal length (ultra-wide)
    @OptIn(ExperimentalCamera2Interop::class)
    private fun detectUltra() {
        val provider = cameraProvider ?: return
        try {
            val infos = provider.availableCameraInfos
            val main = CameraSelector.DEFAULT_BACK_CAMERA.filter(infos).firstOrNull() ?: return
            val mainId = Camera2CameraInfo.from(main).cameraId
            fun focal(i: CameraInfo): Float =
                Camera2CameraInfo.from(i)
                    .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                    ?.minOrNull() ?: 0f
            val mainFocal = focal(main)
            val ultra = infos
                .filter { it.lensFacing == CameraSelector.LENS_FACING_BACK && Camera2CameraInfo.from(it).cameraId != mainId }
                .filter { val f = focal(it); f > 0f && f < mainFocal * 0.75f }
                .minByOrNull { focal(it) }
            ultraId = ultra?.let { Camera2CameraInfo.from(it).cameraId }
        } catch (_: Exception) {
        }
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun bindCamera() {
        val provider = cameraProvider ?: return
        val wantedId = ultraId
        val selector = when {
            facingFront -> CameraSelector.DEFAULT_FRONT_CAMERA
            ultraActive && wantedId != null -> CameraSelector.Builder()
                .addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == wantedId } }
                .build()
            else -> CameraSelector.DEFAULT_BACK_CAMERA
        }

        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

        val photoSelector = ResolutionSelector.Builder()
            .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
            .build()
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(photoSelector)
            .setFlashMode(captureFlashMode())
            .build()

        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(960, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    ).build()
            )
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
        analysis.setAnalyzer(analysisExecutor) { img -> onFrame(img) }

        synchronized(lock) { buffer.clear() }
        try {
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, selector, preview, imageCapture, analysis)
            applyZoom()
        } catch (e: Exception) {
            if (ultraActive) {
                ultraActive = false
                lens = 1
                updateZoomUi()
                Toast.makeText(this, "El ultra gran angular no se puede usar con Live en este teléfono", Toast.LENGTH_LONG).show()
                bindCamera()
            } else {
                Toast.makeText(this, "Error de cámara: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- Rolling frame buffer (pre-roll) ----------

    private fun onFrame(img: ImageProxy) {
        val ts = img.imageInfo.timestamp
        val w = img.width
        val h = img.height
        val rot = img.imageInfo.rotationDegrees
        val frame = Frame(toI420(img), ts, SystemClock.elapsedRealtimeNanos())
        img.close()

        var snapshot: List<Frame>? = null
        var audioSnap: List<AudioChunk> = emptyList()
        synchronized(lock) {
            buffer.addLast(frame)
            if (!capturing) {
                while (buffer.size > 1 && ts - buffer.first().ts > PRE_NS) buffer.removeFirst()
            } else if (ts - shutterTs >= POST_NS) {
                capturing = false
                snapshot = ArrayList(buffer)
                audioSnap = ArrayList(audioBuffer)
                while (buffer.size > 1 && ts - buffer.first().ts > PRE_NS) buffer.removeFirst()
                val limit = frame.arrival - PRE_NS - 300_000_000L
                while (audioBuffer.size > 1 && audioBuffer.first().startNs < limit) audioBuffer.removeFirst()
            }
        }
        snapshot?.let { snap ->
            val latch = photoLatch
            val shotShutterTs = shutterTs
            encodeExecutor.execute { finishShot(snap, audioSnap, w, h, rot, shotShutterTs, latch) }
        }
    }

    private fun toI420(img: ImageProxy): ByteArray {
        val w = img.width
        val h = img.height
        val out = ByteArray(w * h * 3 / 2)
        copyPlane(img.planes[0], w, h, out, 0)
        copyPlane(img.planes[1], w / 2, h / 2, out, w * h)
        copyPlane(img.planes[2], w / 2, h / 2, out, w * h + w * h / 4)
        return out
    }

    private fun copyPlane(p: ImageProxy.PlaneProxy, cw: Int, ch: Int, out: ByteArray, offset: Int) {
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        var o = offset
        for (r in 0 until ch) {
            val rowStart = r * rs
            if (ps == 1) {
                buf.position(rowStart)
                buf.get(out, o, cw)
                o += cw
            } else {
                for (c in 0 until cw) out[o++] = buf.get(rowStart + c * ps)
            }
        }
    }

    // ---------- Shutter ----------

    private fun onShutter() {
        if (busy || imageCapture == null) return
        busy = true
        if (facingFront && flashState == 1) {
            startScreenFlash()
            uiHandler.postDelayed({ doCapture() }, 350)
        } else {
            doCapture()
        }
    }

    private fun doCapture() {
        synchronized(lock) {
            if (capturing || buffer.isEmpty()) {
                busy = false
                endScreenFlash()
                return
            }
            capturing = true
            shutterTs = buffer.last().ts
            photoLatch = CountDownLatch(1)
        }
        status.text = "● LIVE"

        val file = File(cacheDir, "photo_${System.currentTimeMillis()}.jpg")
        photoFile = file
        val latch = photoLatch
        imageCapture!!.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    latch.countDown()
                    endScreenFlash()
                }
                override fun onError(e: ImageCaptureException) {
                    photoFile = null
                    latch.countDown()
                    endScreenFlash()
                }
            })
    }

    // ---------- Encode + pack Motion Photo ----------

    private fun finishShot(
        frames: List<Frame>, audio: List<AudioChunk>, w: Int, h: Int, rot: Int,
        shotTs: Long, latch: CountDownLatch
    ) {
        try {
            val mp4 = File(cacheDir, "clip_${System.currentTimeMillis()}.mp4")
            mux(frames, audio, w, h, rot, mp4)
            latch.await(10, TimeUnit.SECONDS)
            val photo = photoFile ?: throw IllegalStateException("No se pudo tomar la foto")
            val presUs = (shotTs - frames.first().ts) / 1000
            val packed = packMotionPhoto(photo.readBytes(), mp4.readBytes(), presUs)
            val savedUri = save(packed)
            photo.delete(); mp4.delete()
            runOnUiThread { loadThumb(savedUri) }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        } finally {
            runOnUiThread { status.text = ""; busy = false; endScreenFlash() }
        }
    }

    private fun mux(frames: List<Frame>, audio: List<AudioChunk>, w: Int, h: Int, rotation: Int, out: File) {
        val video = encodeVideo(frames, w, h)
        val aud = encodeAudio(audio, frames.first().arrival)

        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer.setOrientationHint(rotation)
        val vt = muxer.addTrack(video.first)
        val at = if (aud != null) muxer.addTrack(aud.first) else -1
        muxer.start()

        val vs = video.second
        val asamples = aud?.second ?: emptyList()
        val info = MediaCodec.BufferInfo()
        var vi = 0
        var ai = 0
        while (vi < vs.size || ai < asamples.size) {
            val useV = ai >= asamples.size || (vi < vs.size && vs[vi].pts <= asamples[ai].pts)
            val s = if (useV) vs[vi++] else asamples[ai++]
            info.set(0, s.data.size, s.pts, s.flags)
            muxer.writeSampleData(if (useV) vt else at, ByteBuffer.wrap(s.data), info)
        }
        muxer.stop(); muxer.release()
    }

    private fun encodeVideo(frames: List<Frame>, w: Int, h: Int): Pair<MediaFormat, List<Sample>> {
        val format = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, 10_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType("video/avc")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val samples = ArrayList<Sample>()
        var outFormat: MediaFormat? = null
        val info = MediaCodec.BufferInfo()
        val t0 = frames.first().ts
        var idx = 0
        var inputDone = false
        var outputDone = false
        while (!outputDone) {
            if (!inputDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    if (idx < frames.size) {
                        val f = frames[idx]
                        fillImage(codec.getInputImage(i)!!, f.data, w, h)
                        codec.queueInputBuffer(i, 0, w * h * 3 / 2, (f.ts - t0) / 1000, 0)
                        idx++
                    } else {
                        codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                outFormat = codec.outputFormat
            } else if (o >= 0) {
                val data = codec.getOutputBuffer(o)!!
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (info.size > 0 && !isConfig) {
                    val bytes = ByteArray(info.size)
                    data.position(info.offset); data.limit(info.offset + info.size)
                    data.get(bytes)
                    samples.add(Sample(bytes, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME))
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        codec.stop(); codec.release()
        return Pair(outFormat ?: throw IllegalStateException("Sin formato de video"), samples)
    }

    private fun encodeAudio(chunks: List<AudioChunk>, firstArrival: Long): Pair<MediaFormat, List<Sample>>? {
        val relevant = chunks.filter {
            it.startNs + (it.data.size / 2) * 1_000_000_000L / SAMPLE_RATE >= firstArrival
        }
        if (relevant.isEmpty()) return null
        val base = maxOf(0L, (relevant.first().startNs - firstArrival) / 1000) + AUDIO_OFFSET_US
        val pcmStream = ByteArrayOutputStream()
        relevant.forEach { pcmStream.write(it.data) }
        val pcm = pcmStream.toByteArray()

        val format = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType("audio/mp4a-latm")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val samples = ArrayList<Sample>()
        var outFormat: MediaFormat? = null
        val info = MediaCodec.BufferInfo()
        var offset = 0
        var inputDone = false
        var outputDone = false
        while (!outputDone) {
            if (!inputDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val pts = base + (offset / 2) * 1_000_000L / SAMPLE_RATE
                    if (offset < pcm.size) {
                        val buf = codec.getInputBuffer(i)!!
                        buf.clear()
                        val n = minOf(buf.capacity(), pcm.size - offset)
                        buf.put(pcm, offset, n)
                        codec.queueInputBuffer(i, 0, n, pts, 0)
                        offset += n
                    } else {
                        codec.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                outFormat = codec.outputFormat
            } else if (o >= 0) {
                val data = codec.getOutputBuffer(o)!!
                val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                if (info.size > 0 && !isConfig) {
                    val bytes = ByteArray(info.size)
                    data.position(info.offset); data.limit(info.offset + info.size)
                    data.get(bytes)
                    samples.add(Sample(bytes, info.presentationTimeUs, 0))
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
        codec.stop(); codec.release()
        return Pair(outFormat ?: return null, samples)
    }

    private fun fillImage(img: Image, src: ByteArray, w: Int, h: Int) {
        val offsets = intArrayOf(0, w * h, w * h + w * h / 4)
        val widths = intArrayOf(w, w / 2, w / 2)
        val heights = intArrayOf(h, h / 2, h / 2)
        for (p in 0 until 3) {
            val plane = img.planes[p]
            val buf = plane.buffer
            val rs = plane.rowStride
            val ps = plane.pixelStride
            for (r in 0 until heights[p]) {
                val srcOff = offsets[p] + r * widths[p]
                if (ps == 1) {
                    buf.position(r * rs)
                    buf.put(src, srcOff, widths[p])
                } else {
                    for (c in 0 until widths[p]) buf.put(r * rs + c * ps, src[srcOff + c])
                }
            }
        }
    }

    private fun packMotionPhoto(jpeg: ByteArray, mp4: ByteArray, presUs: Long): ByteArray {
        val xmp = """
            <x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:GCamera="http://ns.google.com/photos/1.0/camera/" xmlns:Container="http://ns.google.com/photos/1.0/container/" xmlns:Item="http://ns.google.com/photos/1.0/container/item/" GCamera:MotionPhoto="1" GCamera:MotionPhotoVersion="1" GCamera:MotionPhotoPresentationTimestampUs="$presUs"><Container:Directory><rdf:Seq><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/></rdf:li><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/></rdf:li></rdf:Seq></Container:Directory></rdf:Description></rdf:RDF></x:xmpmeta>
        """.trimIndent()
        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val xmpBytes = xmp.toByteArray(Charsets.UTF_8)
        val segLen = 2 + header.size + xmpBytes.size

        // Insert after the existing APP0/APP1 (EXIF) segments
        var pos = 2
        while (pos + 4 < jpeg.size && (jpeg[pos].toInt() and 0xFF) == 0xFF) {
            val m = jpeg[pos + 1].toInt() and 0xFF
            if (m != 0xE0 && m != 0xE1) break
            val len = ((jpeg[pos + 2].toInt() and 0xFF) shl 8) or (jpeg[pos + 3].toInt() and 0xFF)
            pos += 2 + len
        }
        val out = ByteArrayOutputStream(jpeg.size + mp4.size + segLen + 4)
        out.write(jpeg, 0, pos)
        out.write(0xFF); out.write(0xE1)
        out.write(segLen shr 8); out.write(segLen and 0xFF)
        out.write(header); out.write(xmpBytes)
        out.write(jpeg, pos, jpeg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }

    private fun save(bytes: ByteArray): Uri {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_$name.MP")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiveCam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo guardar")
        contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        return uri
    }
}

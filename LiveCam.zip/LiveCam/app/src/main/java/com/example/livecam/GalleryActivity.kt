package com.example.livecam

import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.graphics.SurfaceTexture
import android.view.MotionEvent
import androidx.core.view.doOnLayout
import java.io.ByteArrayOutputStream
import android.view.Surface
import android.view.TextureView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.content.ContentValues
import android.content.Intent
import android.provider.MediaStore
import android.text.SpannableStringBuilder
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import androidx.recyclerview.widget.LinearLayoutManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.max
import android.graphics.Rect

class GalleryActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var root: View
    private lateinit var video: TextureView
    private var mp: MediaPlayer? = null
    private var surf: Surface? = null
    private lateinit var counter: TextView
    private lateinit var liveBadge: TextView
    private lateinit var editBtn: View
    private lateinit var picker: View
    private lateinit var pickVideo: TextureView
    private lateinit var pickStrip: FrameLayout
    private lateinit var pickThumbs: LinearLayout
    private lateinit var pickSel: View
    private var scrub: MediaPlayer? = null
    private var scrubSurf: Surface? = null
    private var scrubReady = false
    private var seeking = false
    private var pending = -1
    private var durMs = 0
    private var curMs = 0
    private var uris: List<Uri> = emptyList()
    private var shown = -1
    private var dates: List<Long> = emptyList()
    private lateinit var strip: RecyclerView
    private lateinit var stripLm: LinearLayoutManager
    private lateinit var favBtn: ImageView
    private var isFav = false
    private var curQ = -1
    private val thumbCache = LruCache<Int, Bitmap>(400)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private var loadJob: Runnable? = null
    private val vinfoCache = java.util.concurrent.ConcurrentHashMap<String, IntArray>()
    private class TexState(var applied: Boolean = true, var checked: Boolean = false)
    private val liveTex = TexState()
    private val pickTex = TexState()
    private var wantPlay = false
    private var burstN = 1
    /** While a Live xN plays, the bottom strip glides through the photos of the burst (like iPhone). */
    private val tick = object : Runnable {
        override fun run() {
            val m = mp
            if (!playing || m == null || burstN < 2) return
            try {
                val f = (m.currentPosition.toFloat() / m.duration.coerceAtLeast(1)).coerceIn(0f, 1f)
                val q = (pager.currentItem - (burstN - 1) + Math.round(f * (burstN - 1))).coerceIn(0, uris.size - 1)
                if (q != curQ) updateStrip(q)
            } catch (_: Exception) {}
            handler.postDelayed(this, 40)
        }
    }

    /** [rotation, rawWidth, rawHeight] of a video file (cached). */
    private fun vinfo(f: File?): IntArray {
        if (f == null) return intArrayOf(0, 0, 0)
        return vinfoCache.getOrPut(f.path) {
            try {
                val r = MediaMetadataRetriever(); r.setDataSource(f.path)
                fun g(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
                val a = intArrayOf(g(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION),
                    g(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH), g(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT))
                r.release(); a
            } catch (_: Exception) { intArrayOf(0, 0, 0) }
        }
    }

    /** Detects (on the first frame) whether the system already rotated the video inside the texture. */
    private fun texListener(tv: TextureView, ts: TexState, onAvail: ((SurfaceTexture) -> Unit)? = null, onDestroy: (() -> Unit)? = null) =
        object : TextureView.SurfaceTextureListener {
            val mx = FloatArray(16)
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { onAvail?.invoke(st) }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { onDestroy?.invoke(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {
                if (ts.checked) return
                ts.checked = true
                try {
                    st.getTransformMatrix(mx)
                    val ap = abs(mx[0]) < 0.5f
                    if (ap != ts.applied) { ts.applied = ap; fitTo(tv, 0, 0) }
                } catch (_: Exception) {}
            }
        }
    private var videoFile: File? = null
    private var playFile: File? = null
    private var videoStartMs = 0
    private var playing = false
    @Volatile private var longPending = false
    private val handler = Handler(Looper.getMainLooper())
    private val imgPool = Executors.newFixedThreadPool(3)
    private val videoPool = Executors.newSingleThreadExecutor()
    private val autoPlay = Runnable { play() }
    private val cache = LruCache<Int, Bitmap>(5)

    class VH(val fl: FrameLayout, val iv: ZoomImageView) : RecyclerView.ViewHolder(fl)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        root = findViewById(R.id.root)
        pager = findViewById(R.id.pager)
        video = findViewById(R.id.video)
        counter = findViewById(R.id.counter)
        liveBadge = findViewById(R.id.liveBadge)
        editBtn = findViewById(R.id.editBtn)
        picker = findViewById(R.id.picker)
        pickVideo = findViewById(R.id.pickVideo)
        pickStrip = findViewById(R.id.pickStrip)
        pickThumbs = findViewById(R.id.pickThumbs)
        pickSel = findViewById(R.id.pickSel)
        editBtn.setOnClickListener { openPicker() }
        findViewById<View>(R.id.pickCancel).setOnClickListener { closePicker() }
        findViewById<View>(R.id.pickSave).setOnClickListener { saveKey() }
        pickVideo.surfaceTextureListener = texListener(pickVideo, pickTex, { startScrub(it) }, { stopScrub() })
        video.surfaceTextureListener = texListener(video, liveTex)
        // Drag the white frame over the filmstrip: the big preview follows live
        pickStrip.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                val sw = pickSel.width
                val range = (v.width - sw).coerceAtLeast(1)
                setPick(((e.x - sw / 2f) / range).coerceIn(0f, 1f))
            }
            true
        }
        findViewById<View>(R.id.close).setOnClickListener { finish() }
        favBtn = findViewById(R.id.favBtn)
        val blue = 0xFF0A84FF.toInt()
        listOf(R.id.shareBtn, R.id.favBtn, R.id.infoBtn, R.id.editBtn, R.id.trashBtn)
            .forEach { findViewById<ImageView>(it).setColorFilter(blue) }
        findViewById<View>(R.id.shareBtn).setOnClickListener { shareCurrent() }
        favBtn.setOnClickListener { toggleFav() }
        findViewById<View>(R.id.infoBtn).setOnClickListener { showInfo() }
        findViewById<View>(R.id.trashBtn).setOnClickListener { deleteCurrent() }

        uris = Media.queryLive(this)
        dates = Media.queryLiveDates(this)
        if (uris.isEmpty()) {
            Toast.makeText(this, "Aún no hay fotos Live", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        pager.adapter = object : RecyclerView.Adapter<VH>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
                val fl = FrameLayout(p.context)
                fl.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                val iv = ZoomImageView(p.context)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                fl.addView(iv, FrameLayout.LayoutParams(-1, -1))
                iv.onLong = { play() }
                iv.onRelease = { wantPlay = false; stopVideo(true) }
                iv.onSwipeDown = { dismissGallery() }
                iv.onZoom = { handler.removeCallbacks(autoPlay); stopVideo(false) }
                return VH(fl, iv)
            }
            override fun onBindViewHolder(h: VH, q: Int) {
                val pos = uris.size - 1 - q   // pager shows oldest -> newest
                val iv = h.iv
                iv.reset()
                iv.tag = pos
                val c = cache.get(pos)
                if (c != null) { iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                imgPool.execute {
                    // 1) tiny version right away, 2) sharp version replaces it
                    val q = Media.decode(this@GalleryActivity, uris[pos], 512)
                    if (q != null) runOnUiThread { if (iv.tag == pos && cache.get(pos) == null) iv.setImageBitmap(q) }
                    val b = Media.decode(this@GalleryActivity, uris[pos], 2048)
                    if (b != null) {
                        cache.put(pos, b)
                        runOnUiThread { if (iv.tag == pos) iv.setImageBitmap(b) }
                    }
                }
            }
        }
        pager.offscreenPageLimit = 1
        // Smooth "zoom + fade" transition while swiping
        pager.setPageTransformer { page, pos ->
            val a = min(abs(pos), 1f)
            val s = 1f - 0.12f * a
            page.scaleX = s
            page.scaleY = s
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrollStateChanged(state: Int) {
                if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    handler.removeCallbacks(autoPlay)
                    stopVideo(false)
                }
            }
            override fun onPageSelected(position: Int) {
                onShown(uris.size - 1 - position)
                updateStrip(position)
            }
        })
        strip = findViewById(R.id.strip)
        stripLm = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        strip.layoutManager = stripLm
        strip.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val iv = ImageView(p.context)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                return object : RecyclerView.ViewHolder(iv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, q: Int) {
                val iv = h.itemView as ImageView
                val ix = uris.size - 1 - q
                val sel = q == curQ
                iv.layoutParams = RecyclerView.LayoutParams(dp(if (sel) 40 else 26), dp(if (sel) 52 else 44)).apply {
                    setMargins(dp(1), dp(if (sel) 0 else 4), dp(1), 0) }
                iv.tag = ix
                iv.setOnClickListener { pager.setCurrentItem(q, true) }
                val c = thumbCache.get(ix)
                if (c != null) { iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                imgPool.execute {
                    val b = Media.decode(this@GalleryActivity, uris[ix], 128)
                    if (b != null) { thumbCache.put(ix, b); runOnUiThread { if (iv.tag == ix) iv.setImageBitmap(b) } }
                }
            }
        }
        val start = intent.getIntExtra("pos", 0).coerceIn(0, uris.size - 1)
        val q0 = uris.size - 1 - start
        if (q0 > 0) pager.setCurrentItem(q0, false)
        onShown(start)
        updateStrip(q0)
    }

    private fun updateStrip(q: Int) {
        val prev = curQ
        curQ = q
        if (prev >= 0) strip.adapter?.notifyItemChanged(prev)
        strip.adapter?.notifyItemChanged(q)
        stripLm.scrollToPositionWithOffset(q, strip.width / 2 - dp(20))
    }

    private fun updateHeader(p: Int) {
        val t = dates.getOrNull(p) ?: return
        val c = Calendar.getInstance(); val n = Calendar.getInstance(); c.timeInMillis = t
        val day = when {
            c.get(Calendar.YEAR) == n.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == n.get(Calendar.DAY_OF_YEAR) -> "Hoy"
            c.get(Calendar.YEAR) == n.get(Calendar.YEAR) && c.get(Calendar.DAY_OF_YEAR) == n.get(Calendar.DAY_OF_YEAR) - 1 -> "Ayer"
            else -> SimpleDateFormat("d 'de' MMM 'de' yyyy", Locale("es")).format(Date(t))
        }
        val time = SimpleDateFormat("h:mm a", Locale("es")).format(Date(t))
        val sb = SpannableStringBuilder(day + "\n" + time)
        sb.setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, day.length, 0)
        sb.setSpan(RelativeSizeSpan(0.8f), day.length + 1, sb.length, 0)
        counter.text = sb
    }

    private fun loadFav(p: Int) {
        isFav = false; favBtn.setImageResource(R.drawable.ic_heart)
        if (android.os.Build.VERSION.SDK_INT < 30) return
        val u = uris[p]
        Thread {
            val fav = try {
                contentResolver.query(u, arrayOf(MediaStore.MediaColumns.IS_FAVORITE), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getInt(0) == 1 else false } ?: false
            } catch (_: Exception) { false }
            runOnUiThread { if (shown == p) { isFav = fav; favBtn.setImageResource(if (fav) R.drawable.ic_heart_fill else R.drawable.ic_heart) } }
        }.start()
    }

    private fun toggleFav() {
        if (android.os.Build.VERSION.SDK_INT < 30 || shown < 0) return
        val u = uris[shown]
        isFav = !isFav
        favBtn.setImageResource(if (isFav) R.drawable.ic_heart_fill else R.drawable.ic_heart)
        favBtn.animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction { favBtn.animate().scaleX(1f).scaleY(1f).setDuration(140).start() }.start()
        try { contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_FAVORITE, if (isFav) 1 else 0) }, null, null) } catch (_: Exception) {}
    }

    private fun shareCurrent() {
        if (shown < 0) return
        val i = Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM, uris[shown])
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Compartir"))
    }

    private fun showInfo() {
        if (shown < 0) return
        val u = uris[shown]
        val sb = StringBuilder()
        try {
            contentResolver.query(u, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT), null, null, null)?.use {
                if (it.moveToFirst()) sb.append(it.getString(0)).append("\n")
                    .append(String.format(Locale.US, "%.1f MB", it.getLong(1) / 1048576f)).append("  ·  ")
                    .append(it.getInt(2)).append("×").append(it.getInt(3))
            }
        } catch (_: Exception) {}
        val info = Media.liveMeta(this, u)
        if (info.burst > 1) sb.append("\nLive largo: ").append(info.burst).append(" fotos")
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Información").setMessage(sb.toString())
            .setPositiveButton("OK", null).show()
    }

    private fun deleteCurrent() {
        if (shown < 0) return
        val u = uris[shown]
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(u))
                @Suppress("DEPRECATION") startIntentSenderForResult(pi.intentSender, 77, null, 0, 0, 0)
            } else { contentResolver.delete(u, null, null); reloadAfterDelete() }
        } catch (e: Exception) { Toast.makeText(this, "No se pudo borrar: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun reloadAfterDelete() { intent.putExtra("pos", shown); recreate() }

    @Suppress("DEPRECATION")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        if (r == 77 && res == RESULT_OK) reloadAfterDelete()
    }

    private fun onShown(p: Int) {
        if (p == shown) return
        shown = p
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        videoFile = null
        playFile = null
        burstN = 1
        longPending = false
        liveBadge.visibility = View.INVISIBLE
        editBtn.visibility = View.INVISIBLE
        updateHeader(p)
        loadFav(p)
        prefetch(p - 1); prefetch(p + 1)
        val uri = uris[p]
        loadJob?.let { handler.removeCallbacks(it) }
        loadJob = Runnable { videoPool.execute {
            if (shown != p) return@execute
            val f = Media.extractVideo(this, uri)
            val info = if (f != null) Media.liveMeta(this, uri) else Media.LiveMeta(0, 1, null, 0, 0L)
            vinfo(f)   // rotation/size ready before the first play
            val st = info.startMs
            val burst = info.burst
            val cover = burst > 1 && info.idx == burst - 1 && info.id != null
            val full = info.full
            longPending = f != null && cover && !full
            runOnUiThread {
                if (shown != p) return@runOnUiThread
                videoFile = f
                videoStartMs = st
                playFile = f
                if (wantPlay && !playing && !longPending) play()   // wait for the complete burst clip
                if (f != null) {
                    burstN = if (cover) burst else 1
                    liveBadge.text = if (cover) "● LIVE ×$burst" else "● LIVE"
                    liveBadge.visibility = View.VISIBLE
                    editBtn.visibility = View.VISIBLE
                } else {
                    Toast.makeText(this, "No se encontró el clip Live en esta foto", Toast.LENGTH_SHORT).show()
                }
            }
            // warm up neighbours so swiping to them plays instantly
            for (q in intArrayOf(p - 1, p + 1)) if (q in uris.indices && shown == p) {
                Media.extractVideo(this, uris[q])?.let { vinfo(it) }; Media.liveMeta(this, uris[q])
            }
            if (f != null && cover && !full) {   // old photos: join the clips; new ones carry the whole Live
                val lf = Media.buildLong(this, uris, p, info)
                runOnUiThread {
                    if (shown != p) return@runOnUiThread
                    if (lf != null) { playFile = lf; videoStartMs = 0 }
                    else Toast.makeText(this, "No se pudo unir el Live largo: ${Media.lastErr ?: "faltan clips"}", Toast.LENGTH_LONG).show()
                    longPending = false
                    if (wantPlay && !playing) play()
                }
            }
        } }
        handler.postDelayed(loadJob!!, 60)   // debounce: no heavy work while swiping fast
    }

    // ---------- Pick key photo (like iPhone) ----------

    private fun openPicker() {
        val f = videoFile ?: return
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        picker.visibility = View.VISIBLE
        pickThumbs.removeAllViews()
        if (pickVideo.isAvailable) pickVideo.surfaceTexture?.let { startScrub(it) }
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.path)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 3000
                val n = 12
                runOnUiThread {
                    for (i in 0 until n) {
                        val iv = ImageView(this)
                        iv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        iv.scaleType = ImageView.ScaleType.CENTER_CROP
                        pickThumbs.addView(iv)
                    }
                    pickStrip.doOnLayout {
                        pickSel.layoutParams = pickSel.layoutParams.also { lp -> lp.width = pickStrip.width / n }
                        pickSel.requestLayout()
                        pickSel.post { if (durMs > 0) setPick(curMs.toFloat() / durMs) }
                    }
                }
                for (i in 0 until n) {
                    val t = (d.toLong() - 1) * i / (n - 1) * 1000L
                    val b = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (b != null) {
                        val sm = Bitmap.createScaledBitmap(b, 96, 128, true)
                        runOnUiThread { (pickThumbs.getChildAt(i) as? ImageView)?.setImageBitmap(sm) }
                    }
                }
                r.release()
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun startScrub(st: SurfaceTexture) {
        val path = videoFile?.path ?: return
        stopScrub()
        pickTex.checked = false; pickTex.applied = true
        val s = Surface(st)
        scrubSurf = s
        val m = MediaPlayer()
        scrub = m
        try {
            m.setDataSource(path)
            m.setSurface(s)
            m.setOnVideoSizeChangedListener { _, w, h -> fitTo(pickVideo, w, h) }
            m.setOnSeekCompleteListener {
                seeking = false
                if (pending >= 0) { val p = pending; pending = -1; scrubTo(p) }
            }
            m.setOnPreparedListener { mm ->
                durMs = mm.duration
                fitTo(pickVideo, mm.videoWidth, mm.videoHeight)
                scrubReady = true
                val f = min(1500, durMs / 2).toFloat() / durMs.coerceAtLeast(1)
                pickStrip.doOnLayout { setPick(f) }
            }
            m.setOnErrorListener { _, what, extra ->
                Toast.makeText(this, "Error de vista previa ($what/$extra)", Toast.LENGTH_SHORT).show()
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir el video: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopScrub() {
        scrubReady = false
        seeking = false
        pending = -1
        try { scrub?.release() } catch (_: Exception) {}
        scrub = null
        scrubSurf?.release()
        scrubSurf = null
    }

    // Latest-wins seeking so the preview follows the finger without piling up requests
    private fun scrubTo(ms: Int) {
        val m = scrub ?: return
        if (!scrubReady) return
        if (seeking) { pending = ms; return }
        seeking = true
        try { m.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) { seeking = false }
    }

    private fun setPick(f: Float) {
        val range = (pickStrip.width - pickSel.width).coerceAtLeast(0)
        pickSel.translationX = f * range
        curMs = (f * durMs).toInt()
        scrubTo(curMs)
    }

    private fun closePicker() {
        picker.visibility = View.GONE
        stopScrub()
    }

    private fun saveKey() {
        val f = videoFile ?: return
        val p = curMs
        Toast.makeText(this, "Guardando…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.path)
                val bmp = r.getFrameAtTime(p * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: throw IllegalStateException("No se pudo leer ese cuadro")
                r.release()
                val bo = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 95, bo)
                Media.save(this, Media.pack(bo.toByteArray(), f.readBytes(), p * 1000L))
                runOnUiThread {
                    Toast.makeText(this, "Guardada como nueva foto Live", Toast.LENGTH_LONG).show()
                    closePicker()
                    recreate()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (picker.visibility == View.VISIBLE) closePicker() else super.onBackPressed()
    }

    private fun prefetch(pos: Int) {
        if (pos !in uris.indices || cache.get(pos) != null) return
        imgPool.execute {
            if (cache.get(pos) == null) {
                val b = Media.decode(this, uris[pos], 2048)
                if (b != null) cache.put(pos, b)
            }
        }
    }

    private fun fit(vw0: Int, vh0: Int) = fitTo(video, vw0, vh0)

    private fun fitTo(tv: TextureView, pw: Int, ph: Int) {
        if (tv.width == 0) return
        val w = tv.width.toFloat(); val h = tv.height.toFloat()
        val live = tv === video
        val f = if (!live) videoFile else (playFile ?: videoFile)
        var (rot, rw, rh) = vinfo(f).let { Triple(it[0], it[1], it[2]) }
        val ts = if (live) liveTex else pickTex
        if (rw <= 0 || rh <= 0) {   // no metadata: trust the size the player reports
            val p = if (live) mp else scrub
            rw = pw.takeIf { it > 0 } ?: p?.videoWidth ?: 0; rh = ph.takeIf { it > 0 } ?: p?.videoHeight ?: 0; rot = 0
            if (rw <= 0 || rh <= 0) return
        }
        val sw = rot % 180 != 0
        val dw = (if (sw) rh else rw).toFloat(); val dh = (if (sw) rw else rh).toFloat()   // size as displayed (upright)
        val cx = w / 2f; val cy = h / 2f
        val k: Float
        var clip: Rect? = null
        if (live) {
            // fill exactly the area the photo occupies (center-crop)
            val pb = cache.get(shown)
            val bw = (pb?.width ?: 3).toFloat(); val bh = (pb?.height ?: 4).toFloat()
            val kp = min(w / bw, h / bh); val aw = bw * kp; val ah = bh * kp
            k = max(aw / dw, ah / dh)
            clip = Rect(((w - aw) / 2).toInt(), ((h - ah) / 2).toInt(), ((w + aw) / 2).toInt(), ((h + ah) / 2).toInt())
        } else k = min(w / dw, h / dh)
        val m = Matrix()
        if (ts.applied || rot == 0 || rot == 180) {
            m.setScale(dw * k / w, dh * k / h, cx, cy)
        } else {   // the texture shows the raw (lying) frame stretched: undo the stretch, rotate it upright, scale
            m.setScale(rw / w, rh / h, cx, cy)
            m.postRotate(rot.toFloat(), cx, cy)
            m.postScale(k, k, cx, cy)
        }
        tv.setTransform(m)
        if (clip != null) tv.clipBounds = clip
    }

    /** Pull-down dismissal: shrink/fade the photo back toward the grid before returning. */
    private fun dismissGallery() {
        if (playing) stopVideo(false)
        handler.removeCallbacks(autoPlay)
        root.animate().cancel()
        root.pivotX = root.width / 2f
        root.pivotY = 0f
        root.animate().translationY(root.height * 0.72f).scaleX(0.88f).scaleY(0.88f)
            .alpha(0.25f).setDuration(230)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .withEndAction { finish(); overridePendingTransition(0, 0) }.start()
    }

    private fun releasePlayer() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        surf?.release()
        surf = null
    }

    private fun play(retry: Boolean = true) {
        if (longPending) { wantPlay = true; return }
        val f = playFile ?: videoFile
        if (f == null) {
            wantPlay = true   // starts as soon as it's loaded
            return
        }
        if (playing) return
        val st = video.surfaceTexture
        if (st == null) {
            Toast.makeText(this, "Video no listo, intenta de nuevo", Toast.LENGTH_SHORT).show()
            return
        }
        releasePlayer()
        liveTex.checked = false; liveTex.applied = true
        playing = true
        val s = Surface(st)
        surf = s
        val player = MediaPlayer()
        mp = player
        try {
            java.io.FileInputStream(f).use { player.setDataSource(it.fd) }
            player.setSurface(s)
            player.setOnVideoSizeChangedListener { _, w, h -> fit(w, h) }
            player.setOnPreparedListener { m ->
                if (mp !== m || !playing) return@setOnPreparedListener
                fit(m.videoWidth, m.videoHeight)
                if (videoStartMs > 0 && videoStartMs < m.duration) {
                    m.setOnSeekCompleteListener { mm -> if (mp === mm && playing) go(mm) }
                    m.seekTo(videoStartMs.toLong(), MediaPlayer.SEEK_CLOSEST)
                } else go(m)
            }
            player.setOnCompletionListener { stopVideo(true) }
            player.setOnErrorListener { _, what, extra ->
                stopVideo(false)
                retryPlay(f, retry, "($what/$extra)")
                true
            }
            player.prepareAsync()
        } catch (e: Exception) {
            stopVideo(false)
            retryPlay(f, retry, ": ${e.message}")
        }
    }

    /** A cached clip can be stale (photo rewritten with its final Live): re-extract it once and retry silently. */
    private fun retryPlay(f: File, retry: Boolean, msg: String) {
        val p = shown
        if (!retry || p !in uris.indices) { Toast.makeText(this, "No se pudo reproducir el Live $msg", Toast.LENGTH_SHORT).show(); return }
        f.delete()
        videoPool.execute {
            val nf = Media.extractVideo(this, uris[p])
            runOnUiThread {
                if (shown != p) return@runOnUiThread
                if (nf == null) { Toast.makeText(this, "No se pudo reproducir el Live $msg", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
                if (videoFile == f) videoFile = nf
                playFile = nf
                play(false)
            }
        }
    }

    private fun go(m: MediaPlayer) {
        m.setOnSeekCompleteListener(null)
        m.start()
        // MediaPlayer/TextureView may report its transform one frame after prepare on cold start.
        video.postDelayed({ if (mp === m && playing) fit(m.videoWidth, m.videoHeight) }, 120)
        handler.removeCallbacks(tick); if (burstN > 1) handler.post(tick)
        // iPhone-like: the Live fades in with a soft zoom-out
        video.animate().cancel()
        video.alpha = 0.02f; video.scaleX = 1.05f; video.scaleY = 1.05f
        video.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
    }

    private fun stopVideo(fade: Boolean) {
        wantPlay = false
        if (!playing) return
        playing = false
        handler.removeCallbacks(tick)
        if (burstN > 1 && curQ != pager.currentItem) updateStrip(pager.currentItem)
        video.animate().cancel()
        if (fade) {
            video.animate().alpha(0.02f).scaleX(1.03f).scaleY(1.03f).setDuration(380).withEndAction {
                if (!playing) releasePlayer()
                video.scaleX = 1f; video.scaleY = 1f
            }.start()
        } else {
            video.alpha = 0.02f
            video.scaleX = 1f; video.scaleY = 1f
            releasePlayer()
        }
    }

    override fun onDestroy() {
        cacheDir.listFiles()?.filter { it.name.startsWith("long_") }?.forEach { it.delete() }
        super.onDestroy()
    }

    override fun onStop() {
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        super.onStop()
    }
}

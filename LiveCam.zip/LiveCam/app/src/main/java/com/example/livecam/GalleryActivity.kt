package com.example.livecam

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

class GalleryActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var video: VideoView
    private lateinit var counter: TextView
    private lateinit var liveBadge: View
    private var uris: List<Uri> = emptyList()
    private var shown = -1
    private var videoFile: File? = null
    private var playing = false
    private val handler = Handler(Looper.getMainLooper())
    private val imgPool = Executors.newFixedThreadPool(2)
    private val videoPool = Executors.newSingleThreadExecutor()
    private val autoPlay = Runnable { play() }
    private val cache = LruCache<Int, Bitmap>(4)

    class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        pager = findViewById(R.id.pager)
        video = findViewById(R.id.video)
        counter = findViewById(R.id.counter)
        liveBadge = findViewById(R.id.liveBadge)
        findViewById<View>(R.id.close).setOnClickListener { finish() }

        uris = Media.queryLive(this)
        if (uris.isEmpty()) {
            Toast.makeText(this, "Aún no hay fotos Live", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        pager.adapter = object : RecyclerView.Adapter<VH>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
                val iv = ImageView(p.context)
                iv.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                return VH(iv)
            }
            override fun onBindViewHolder(h: VH, pos: Int) {
                val iv = h.iv
                iv.tag = pos
                iv.setOnLongClickListener { play(); true }
                val c = cache.get(pos)
                if (c != null) { iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                imgPool.execute {
                    val b = Media.decode(this@GalleryActivity, uris[pos], 2)
                    if (b != null) {
                        cache.put(pos, b)
                        runOnUiThread { if (iv.tag == pos) iv.setImageBitmap(b) }
                    }
                }
            }
        }
        pager.offscreenPageLimit = 1
        // Smooth "zoom + fade" transition while swiping
        pager.setPageTransformer { page, pos ->
            val a = min(abs(pos), 1f)
            val s = 1f - 0.18f * a
            page.scaleX = s
            page.scaleY = s
            page.alpha = 1f - 0.6f * a
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrollStateChanged(state: Int) {
                if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    handler.removeCallbacks(autoPlay)
                    stopVideo(false)
                }
            }
            override fun onPageSelected(position: Int) = onShown(position)
        })
        onShown(0)
    }

    private fun onShown(p: Int) {
        if (p == shown) return
        shown = p
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        videoFile = null
        liveBadge.visibility = View.INVISIBLE
        counter.text = "${p + 1} / ${uris.size}"
        val uri = uris[p]
        videoPool.execute {
            val f = Media.extractVideo(this, uri)
            runOnUiThread {
                if (shown == p) {
                    videoFile = f
                    if (f != null) {
                        liveBadge.visibility = View.VISIBLE
                        handler.postDelayed(autoPlay, 400)   // plays once, like iPhone
                    }
                }
            }
        }
    }

    private fun play() {
        val f = videoFile ?: return
        if (playing) return
        playing = true
        video.setOnPreparedListener { mp ->
            if (!playing) return@setOnPreparedListener
            video.animate().cancel()
            video.alpha = 0f
            video.visibility = View.VISIBLE
            mp.start()
            video.animate().alpha(1f).setDuration(120).start()
        }
        video.setOnCompletionListener { stopVideo(true) }
        video.setOnErrorListener { _, _, _ -> stopVideo(false); true }
        video.setVideoURI(Uri.fromFile(f))
    }

    private fun stopVideo(fade: Boolean) {
        if (!playing) return
        playing = false
        video.animate().cancel()
        if (fade) {
            video.animate().alpha(0f).setDuration(250).withEndAction {
                if (!playing) { video.stopPlayback(); video.visibility = View.INVISIBLE }
            }.start()
        } else {
            video.stopPlayback()
            video.visibility = View.INVISIBLE
        }
    }

    override fun onStop() {
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        super.onStop()
    }
}

package com.example.livecam

import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.widget.LinearLayout
import android.widget.SeekBar
import java.io.ByteArrayOutputStream
import android.view.Surface
import android.view.TextureView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

class GalleryActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var video: TextureView
    private var mp: MediaPlayer? = null
    private var surf: Surface? = null
    private lateinit var counter: TextView
    private lateinit var liveBadge: View
    private lateinit var editBtn: View
    private lateinit var picker: View
    private lateinit var pickFrame: ImageView
    private lateinit var pickStrip: LinearLayout
    private lateinit var pickSeek: SeekBar
    private val frameExec = Executors.newSingleThreadExecutor()
    @Volatile private var req = -1
    private var retr: MediaMetadataRetriever? = null
    private var uris: List<Uri> = emptyList()
    private var shown = -1
    private var videoFile: File? = null
    private var playing = false
    private val handler = Handler(Looper.getMainLooper())
    private val imgPool = Executors.newFixedThreadPool(2)
    private val videoPool = Executors.newSingleThreadExecutor()
    private val autoPlay = Runnable { play() }
    private val cache = LruCache<Int, Bitmap>(4)

    class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        pager = findViewById(R.id.pager)
        video = findViewById(R.id.video)
        counter = findViewById(R.id.counter)
        liveBadge = findViewById(R.id.liveBadge)
        editBtn = findViewById(R.id.editBtn)
        picker = findViewById(R.id.picker)
        pickFrame = findViewById(R.id.pickFrame)
        pickStrip = findViewById(R.id.pickStrip)
        pickSeek = findViewById(R.id.pickSeek)
        editBtn.setOnClickListener { openPicker() }
        findViewById<View>(R.id.pickCancel).setOnClickListener { closePicker() }
        findViewById<View>(R.id.pickSave).setOnClickListener { saveKey() }
        pickSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { showFrameAt(p) }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        findViewById<View>(R.id.close).setOnClickListener { finish() }

        uris = Media.queryLive(this)
        if (uris.isEmpty()) {
            Toast.makeText(this, "Aún no hay fotos Live", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        pager.adapter = object : RecyclerView.Adapter<VH>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
                val iv = ImageView(p.context)
                iv.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                return VH(iv)
            }
            override fun onBindViewHolder(h: VH, pos: Int) {
                val iv = h.iv
                iv.tag = pos
                iv.setOnLongClickListener { play(); true }
                val c = cache.get(pos)
                if (c != null) { iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                imgPool.execute {
                    val b = Media.decode(this@GalleryActivity, uris[pos], 2)
                    if (b != null) {
                        cache.put(pos, b)
                        runOnUiThread { if (iv.tag == pos) iv.setImageBitmap(b) }
                    }
                }
            }
        }
        pager.offscreenPageLimit = 1
        // Smooth "zoom + fade" transition while swiping
        pager.setPageTransformer { page, pos ->
            val a = min(abs(pos), 1f)
            val s = 1f - 0.12f * a
            page.scaleX = s
            page.scaleY = s
            page.alpha = 1f - 0.5f * a
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrollStateChanged(state: Int) {
                if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    handler.removeCallbacks(autoPlay)
                    stopVideo(false)
                }
            }
            override fun onPageSelected(position: Int) = onShown(position)
        })
        onShown(0)
    }

    private fun onShown(p: Int) {
        if (p == shown) return
        shown = p
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        videoFile = null
        liveBadge.visibility = View.INVISIBLE
        editBtn.visibility = View.INVISIBLE
        counter.text = "${p + 1} / ${uris.size}"
        prefetch(p - 1); prefetch(p + 1)
        val uri = uris[p]
        videoPool.execute {
            val f = Media.extractVideo(this, uri)
            runOnUiThread {
                if (shown == p) {
                    videoFile = f
                    if (f != null) {
                        liveBadge.visibility = View.VISIBLE
                        editBtn.visibility = View.VISIBLE
                        handler.postDelayed(autoPlay, 400)   // plays once, like iPhone
                    } else {
                        Toast.makeText(this, "No se encontró el clip Live en esta foto", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    // ---------- Pick key photo (like iPhone) ----------

    private fun openPicker() {
        val f = videoFile ?: return
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        picker.visibility = View.VISIBLE
        pickStrip.removeAllViews()
        pickFrame.setImageDrawable(null)
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.path)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 3000
                val n = 10
                runOnUiThread {
                    for (i in 0 until n) {
                        val iv = ImageView(this)
                        iv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        iv.scaleType = ImageView.ScaleType.CENTER_CROP
                        pickStrip.addView(iv)
                    }
                    pickSeek.max = d
                    pickSeek.progress = min(1500, d / 2)
                    showFrameAt(pickSeek.progress)
                }
                for (i in 0 until n) {
                    val t = (d.toLong() - 1) * i / (n - 1) * 1000L
                    val b = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (b != null) {
                        val sm = Bitmap.createScaledBitmap(b, 96, 128, true)
                        runOnUiThread { (pickStrip.getChildAt(i) as? ImageView)?.setImageBitmap(sm) }
                    }
                }
                r.release()
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun showFrameAt(p: Int) {
        val path = videoFile?.path ?: return
        req = p
        frameExec.execute {
            if (req != p) return@execute
            try {
                val r = retr ?: MediaMetadataRetriever().also { it.setDataSource(path); retr = it }
                val b = r.getFrameAtTime(p * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                if (b != null && req == p) runOnUiThread { pickFrame.setImageBitmap(b) }
            } catch (_: Exception) {
            }
        }
    }

    private fun closePicker() {
        picker.visibility = View.GONE
        frameExec.execute { try { retr?.release() } catch (_: Exception) {}; retr = null }
    }

    private fun saveKey() {
        val f = videoFile ?: return
        val p = pickSeek.progress
        Toast.makeText(this, "Guardando…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.path)
                val bmp = r.getFrameAtTime(p * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: throw IllegalStateException("No se pudo leer ese cuadro")
                r.release()
                val bo = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 95, bo)
                Media.save(this, Media.pack(bo.toByteArray(), f.readBytes(), p * 1000L))
                runOnUiThread {
                    Toast.makeText(this, "Guardada como nueva foto Live", Toast.LENGTH_LONG).show()
                    closePicker()
                    recreate()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (picker.visibility == View.VISIBLE) closePicker() else super.onBackPressed()
    }

    private fun prefetch(pos: Int) {
        if (pos !in uris.indices || cache.get(pos) != null) return
        imgPool.execute {
            if (cache.get(pos) == null) {
                val b = Media.decode(this, uris[pos], 2)
                if (b != null) cache.put(pos, b)
            }
        }
    }

    private fun fit(vw0: Int, vh0: Int) {
        if (vw0 <= 0 || vh0 <= 0 || video.width == 0) return
        val w = video.width.toFloat()
        val h = video.height.toFloat()
        val k = min(w / vw0, h / vh0)
        video.setTransform(Matrix().apply { setScale(vw0 * k / w, vh0 * k / h, w / 2f, h / 2f) })
    }

    private fun releasePlayer() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        surf?.release()
        surf = null
    }

    private fun play() {
        val f = videoFile
        if (f == null) {
            Toast.makeText(this, "Cargando Live…", Toast.LENGTH_SHORT).show()
            return
        }
        if (playing) return
        val st = video.surfaceTexture
        if (st == null) {
            Toast.makeText(this, "Video no listo, intenta de nuevo", Toast.LENGTH_SHORT).show()
            return
        }
        releasePlayer()
        playing = true
        val s = Surface(st)
        surf = s
        val player = MediaPlayer()
        mp = player
        try {
            player.setDataSource(f.path)
            player.setSurface(s)
            player.setOnVideoSizeChangedListener { _, w, h -> fit(w, h) }
            player.setOnPreparedListener { m ->
                if (mp !== m || !playing) return@setOnPreparedListener
                fit(m.videoWidth, m.videoHeight)
                m.start()
                video.animate().cancel()
                video.animate().alpha(1f).setDuration(120).start()
            }
            player.setOnCompletionListener { stopVideo(true) }
            player.setOnErrorListener { _, what, extra ->
                stopVideo(false)
                Toast.makeText(this, "No se pudo reproducir el Live ($what/$extra)", Toast.LENGTH_SHORT).show()
                true
            }
            player.prepareAsync()
        } catch (e: Exception) {
            stopVideo(false)
            Toast.makeText(this, "No se pudo reproducir el Live: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopVideo(fade: Boolean) {
        if (!playing) return
        playing = false
        video.animate().cancel()
        if (fade) {
            video.animate().alpha(0.02f).setDuration(250).withEndAction {
                if (!playing) releasePlayer()
            }.start()
        } else {
            video.alpha = 0.02f
            releasePlayer()
        }
    }

    override fun onStop() {
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        super.onStop()
    }
}

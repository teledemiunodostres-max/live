package com.example.livecam

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import kotlin.math.abs

class GalleryActivity : AppCompatActivity() {

    private lateinit var image: ImageView
    private lateinit var video: VideoView
    private lateinit var counter: TextView
    private var uris: List<Uri> = emptyList()
    private var index = 0
    private var videoFile: File? = null
    private var playing = false
    private val handler = Handler(Looper.getMainLooper())
    private val playRunnable = Runnable { play() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        image = findViewById(R.id.image)
        video = findViewById(R.id.video)
        counter = findViewById(R.id.counter)
        findViewById<View>(R.id.close).setOnClickListener { finish() }

        uris = Media.queryLive(this)
        if (uris.isEmpty()) {
            Toast.makeText(this, "Aún no hay fotos Live", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        var downX = 0f
        var downY = 0f
        findViewById<View>(R.id.root).setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y
                    handler.postDelayed(playRunnable, 350)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.x - downX) > 40 || abs(e.y - downY) > 40) handler.removeCallbacks(playRunnable)
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(playRunnable)
                    val dx = e.x - downX
                    if (!playing && abs(dx) > 150 && abs(dx) > abs(e.y - downY)) {
                        if (dx < 0) show(index + 1) else show(index - 1)
                    }
                    stop()
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(playRunnable)
                    stop()
                }
            }
            true
        }
        show(0)
    }

    private fun show(i: Int) {
        if (i !in uris.indices) return
        index = i
        videoFile = null
        stop()
        counter.text = "${i + 1} / ${uris.size}"
        val uri = uris[i]
        Thread {
            val bmp = Media.decode(this, uri, 4)
            runOnUiThread { if (index == i && bmp != null) image.setImageBitmap(bmp) }
            val vf = Media.extractVideo(this, uri)
            runOnUiThread { if (index == i) videoFile = vf }
        }.start()
    }

    private fun play() {
        val f = videoFile ?: return
        playing = true
        video.setOnPreparedListener { video.visibility = View.VISIBLE; it.start() }
        video.setOnCompletionListener { stop() }
        video.setOnErrorListener { _, _, _ -> stop(); true }
        video.setVideoURI(Uri.fromFile(f))
    }

    private fun stop() {
        if (playing) video.stopPlayback()
        playing = false
        video.visibility = View.INVISIBLE
    }
}

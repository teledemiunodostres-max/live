package com.example.livecam

import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.graphics.SurfaceTexture
import android.view.MotionEvent
import androidx.core.view.doOnLayout
import java.io.ByteArrayOutputStream
import android.view.Surface
import android.view.TextureView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

class GalleryActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var video: TextureView
    private var mp: MediaPlayer? = null
    private var surf: Surface? = null
    private lateinit var counter: TextView
    private lateinit var liveBadge: View
    private lateinit var editBtn: View
    private lateinit var picker: View
    private lateinit var pickVideo: TextureView
    private lateinit var pickStrip: FrameLayout
    private lateinit var pickThumbs: LinearLayout
    private lateinit var pickSel: View
    private var scrub: MediaPlayer? = null
    private var scrubSurf: Surface? = null
    private var scrubReady = false
    private var seeking = false
    private var pending = -1
    private var durMs = 0
    private var curMs = 0
    private var uris: List<Uri> = emptyList()
    private var shown = -1
    private var videoFile: File? = null
    private var playing = false
    private val handler = Handler(Looper.getMainLooper())
    private val imgPool = Executors.newFixedThreadPool(2)
    private val videoPool = Executors.newSingleThreadExecutor()
    private val autoPlay = Runnable { play() }
    private val cache = LruCache<Int, Bitmap>(4)

    class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        pager = findViewById(R.id.pager)
        video = findViewById(R.id.video)
        counter = findViewById(R.id.counter)
        liveBadge = findViewById(R.id.liveBadge)
        editBtn = findViewById(R.id.editBtn)
        picker = findViewById(R.id.picker)
        pickVideo = findViewById(R.id.pickVideo)
        pickStrip = findViewById(R.id.pickStrip)
        pickThumbs = findViewById(R.id.pickThumbs)
        pickSel = findViewById(R.id.pickSel)
        editBtn.setOnClickListener { openPicker() }
        findViewById<View>(R.id.pickCancel).setOnClickListener { closePicker() }
        findViewById<View>(R.id.pickSave).setOnClickListener { saveKey() }
        pickVideo.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { startScrub(st) }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { stopScrub(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        // Drag the white frame over the filmstrip: the big preview follows live
        pickStrip.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                val sw = pickSel.width
                val range = (v.width - sw).coerceAtLeast(1)
                setPick(((e.x - sw / 2f) / range).coerceIn(0f, 1f))
            }
            true
        }
        findViewById<View>(R.id.close).setOnClickListener { finish() }

        uris = Media.queryLive(this)
        if (uris.isEmpty()) {
            Toast.makeText(this, "Aún no hay fotos Live", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        pager.adapter = object : RecyclerView.Adapter<VH>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
                val iv = ImageView(p.context)
                iv.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                return VH(iv)
            }
            override fun onBindViewHolder(h: VH, pos: Int) {
                val iv = h.iv
                iv.tag = pos
                iv.setOnLongClickListener { play(); true }
                val c = cache.get(pos)
                if (c != null) { iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                imgPool.execute {
                    val b = Media.decode(this@GalleryActivity, uris[pos], 2)
                    if (b != null) {
                        cache.put(pos, b)
                        runOnUiThread { if (iv.tag == pos) iv.setImageBitmap(b) }
                    }
                }
            }
        }
        pager.offscreenPageLimit = 1
        // Smooth "zoom + fade" transition while swiping
        pager.setPageTransformer { page, pos ->
            val a = min(abs(pos), 1f)
            val s = 1f - 0.12f * a
            page.scaleX = s
            page.scaleY = s
            page.alpha = 1f - 0.5f * a
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrollStateChanged(state: Int) {
                if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    handler.removeCallbacks(autoPlay)
                    stopVideo(false)
                }
            }
            override fun onPageSelected(position: Int) = onShown(position)
        })
        onShown(0)
    }

    private fun onShown(p: Int) {
        if (p == shown) return
        shown = p
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        videoFile = null
        liveBadge.visibility = View.INVISIBLE
        editBtn.visibility = View.INVISIBLE
        counter.text = "${p + 1} / ${uris.size}"
        prefetch(p - 1); prefetch(p + 1)
        val uri = uris[p]
        videoPool.execute {
            val f = Media.extractVideo(this, uri)
            runOnUiThread {
                if (shown == p) {
                    videoFile = f
                    if (f != null) {
                        liveBadge.visibility = View.VISIBLE
                        editBtn.visibility = View.VISIBLE
                        handler.postDelayed(autoPlay, 400)   // plays once, like iPhone
                    } else {
                        Toast.makeText(this, "No se encontró el clip Live en esta foto", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    // ---------- Pick key photo (like iPhone) ----------

    private fun openPicker() {
        val f = videoFile ?: return
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        picker.visibility = View.VISIBLE
        pickThumbs.removeAllViews()
        if (pickVideo.isAvailable) pickVideo.surfaceTexture?.let { startScrub(it) }
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.path)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 3000
                val n = 12
                runOnUiThread {
                    for (i in 0 until n) {
                        val iv = ImageView(this)
                        iv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        iv.scaleType = ImageView.ScaleType.CENTER_CROP
                        pickThumbs.addView(iv)
                    }
                    pickStrip.doOnLayout {
                        pickSel.layoutParams = pickSel.layoutParams.also { lp -> lp.width = pickStrip.width / n }
                        pickSel.requestLayout()
                        pickSel.post { if (durMs > 0) setPick(curMs.toFloat() / durMs) }
                    }
                }
                for (i in 0 until n) {
                    val t = (d.toLong() - 1) * i / (n - 1) * 1000L
                    val b = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (b != null) {
                        val sm = Bitmap.createScaledBitmap(b, 96, 128, true)
                        runOnUiThread { (pickThumbs.getChildAt(i) as? ImageView)?.setImageBitmap(sm) }
                    }
                }
                r.release()
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun startScrub(st: SurfaceTexture) {
        val path = videoFile?.path ?: return
        stopScrub()
        val s = Surface(st)
        scrubSurf = s
        val m = MediaPlayer()
        scrub = m
        try {
            m.setDataSource(path)
            m.setSurface(s)
            m.setOnVideoSizeChangedListener { _, w, h -> fitTo(pickVideo, w, h) }
            m.setOnSeekCompleteListener {
                seeking = false
                if (pending >= 0) { val p = pending; pending = -1; scrubTo(p) }
            }
            m.setOnPreparedListener { mm ->
                durMs = mm.duration
                fitTo(pickVideo, mm.videoWidth, mm.videoHeight)
                scrubReady = true
                val f = min(1500, durMs / 2).toFloat() / durMs.coerceAtLeast(1)
                pickStrip.doOnLayout { setPick(f) }
            }
            m.setOnErrorListener { _, what, extra ->
                Toast.makeText(this, "Error de vista previa ($what/$extra)", Toast.LENGTH_SHORT).show()
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir el video: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopScrub() {
        scrubReady = false
        seeking = false
        pending = -1
        try { scrub?.release() } catch (_: Exception) {}
        scrub = null
        scrubSurf?.release()
        scrubSurf = null
    }

    // Latest-wins seeking so the preview follows the finger without piling up requests
    private fun scrubTo(ms: Int) {
        val m = scrub ?: return
        if (!scrubReady) return
        if (seeking) { pending = ms; return }
        seeking = true
        try { m.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) { seeking = false }
    }

    private fun setPick(f: Float) {
        val range = (pickStrip.width - pickSel.width).coerceAtLeast(0)
        pickSel.translationX = f * range
        curMs = (f * durMs).toInt()
        scrubTo(curMs)
    }

    private fun closePicker() {
        picker.visibility = View.GONE
        stopScrub()
    }

    private fun saveKey() {
        val f = videoFile ?: return
        val p = curMs
        Toast.makeText(this, "Guardando…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(f.path)
                val bmp = r.getFrameAtTime(p * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: throw IllegalStateException("No se pudo leer ese cuadro")
                r.release()
                val bo = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 95, bo)
                Media.save(this, Media.pack(bo.toByteArray(), f.readBytes(), p * 1000L))
                runOnUiThread {
                    Toast.makeText(this, "Guardada como nueva foto Live", Toast.LENGTH_LONG).show()
                    closePicker()
                    recreate()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (picker.visibility == View.VISIBLE) closePicker() else super.onBackPressed()
    }

    private fun prefetch(pos: Int) {
        if (pos !in uris.indices || cache.get(pos) != null) return
        imgPool.execute {
            if (cache.get(pos) == null) {
                val b = Media.decode(this, uris[pos], 2)
                if (b != null) cache.put(pos, b)
            }
        }
    }

    private fun fit(vw0: Int, vh0: Int) = fitTo(video, vw0, vh0)

    private fun fitTo(tv: TextureView, vw0: Int, vh0: Int) {
        if (vw0 <= 0 || vh0 <= 0 || tv.width == 0) return
        val w = tv.width.toFloat()
        val h = tv.height.toFloat()
        val k = min(w / vw0, h / vh0)
        tv.setTransform(Matrix().apply { setScale(vw0 * k / w, vh0 * k / h, w / 2f, h / 2f) })
    }

    private fun releasePlayer() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        surf?.release()
        surf = null
    }

    private fun play() {
        val f = videoFile
        if (f == null) {
            Toast.makeText(this, "Cargando Live…", Toast.LENGTH_SHORT).show()
            return
        }
        if (playing) return
        val st = video.surfaceTexture
        if (st == null) {
            Toast.makeText(this, "Video no listo, intenta de nuevo", Toast.LENGTH_SHORT).show()
            return
        }
        releasePlayer()
        playing = true
        val s = Surface(st)
        surf = s
        val player = MediaPlayer()
        mp = player
        try {
            player.setDataSource(f.path)
            player.setSurface(s)
            player.setOnVideoSizeChangedListener { _, w, h -> fit(w, h) }
            player.setOnPreparedListener { m ->
                if (mp !== m || !playing) return@setOnPreparedListener
                fit(m.videoWidth, m.videoHeight)
                m.start()
                video.animate().cancel()
                video.animate().alpha(1f).setDuration(120).start()
            }
            player.setOnCompletionListener { stopVideo(true) }
            player.setOnErrorListener { _, what, extra ->
                stopVideo(false)
                Toast.makeText(this, "No se pudo reproducir el Live ($what/$extra)", Toast.LENGTH_SHORT).show()
                true
            }
            player.prepareAsync()
        } catch (e: Exception) {
            stopVideo(false)
            Toast.makeText(this, "No se pudo reproducir el Live: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopVideo(fade: Boolean) {
        if (!playing) return
        playing = false
        video.animate().cancel()
        if (fade) {
            video.animate().alpha(0.02f).setDuration(250).withEndAction {
                if (!playing) releasePlayer()
            }.start()
        } else {
            video.alpha = 0.02f
            releasePlayer()
        }
    }

    override fun onStop() {
        handler.removeCallbacks(autoPlay)
        stopVideo(false)
        super.onStop()
    }
}

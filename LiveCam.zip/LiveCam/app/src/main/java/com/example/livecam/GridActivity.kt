package com.example.livecam

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.LruCache
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/** iPhone-style photo grid: newest at the bottom, scroll up for older ones. */
class GridActivity : AppCompatActivity() {
    private var uris: List<Uri> = emptyList()      // newest first (same order as GalleryActivity)
    private val cache = LruCache<Int, Bitmap>(150)
    private val pool = Executors.newFixedThreadPool(4)
    private lateinit var rv: RecyclerView
    private lateinit var adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()); fitsSystemWindows = true }
        rv = RecyclerView(this)
        rv.layoutManager = GridLayoutManager(this, 3)
        rv.setPadding(0, dp(56), 0, 0)
        rv.clipToPadding = false
        root.addView(rv, FrameLayout.LayoutParams(-1, -1))
        root.addView(TextView(this).apply {
            text = "‹  Cámara"; setTextColor(0xFFFFD60A.toInt()); textSize = 17f
            setPadding(dp(16), dp(14), dp(16), dp(14)); setBackgroundColor(0xCC000000.toInt())
            setOnClickListener { finish() }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(TextView(this).apply {
            text = "Fotos Live"; setTextColor(0xFFFFFFFF.toInt()); textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(14), 0, dp(14))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setContentView(root)

        adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val iv = ImageView(p.context)
                val size = p.width / 3
                iv.layoutParams = ViewGroup.LayoutParams(size, size)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.setPadding(1, 1, 1, 1)
                iv.setBackgroundColor(0xFF111111.toInt())
                return object : RecyclerView.ViewHolder(iv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val iv = h.itemView as ImageView
                val gi = uris.size - 1 - pos            // grid shows oldest -> newest
                iv.tag = gi
                iv.setOnClickListener {
                    startActivity(Intent(this@GridActivity, GalleryActivity::class.java).putExtra("pos", gi))
                }
                val c = cache.get(gi)
                if (c != null) { iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                pool.execute {
                    val b = Media.decode(this@GridActivity, uris[gi], 256)
                    if (b != null) {
                        cache.put(gi, b)
                        runOnUiThread { if (iv.tag == gi) iv.setImageBitmap(b) }
                    }
                }
            }
        }
        rv.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        Thread {
            val l = Media.queryLive(this)
            runOnUiThread {
                if (l.size != uris.size) {
                    uris = l
                    cache.evictAll()
                    adapter.notifyDataSetChanged()
                    if (l.isNotEmpty()) rv.scrollToPosition(l.size - 1)
                }
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

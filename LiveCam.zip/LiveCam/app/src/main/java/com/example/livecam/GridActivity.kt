package com.example.livecam

import android.app.ActivityOptions
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** iPhone Photos style: newest at the bottom, date header, floating tab pill, pinch to change density. */
class GridActivity : AppCompatActivity() {
    private var uris: List<Uri> = emptyList()      // newest first (same order as GalleryActivity)
    private var dates: List<Long> = emptyList()
    private val cache = LruCache<Int, Bitmap>(250)
    private val pool = Executors.newFixedThreadPool(4)
    private lateinit var rv: RecyclerView
    private lateinit var lm: GridLayoutManager
    private lateinit var adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>
    private lateinit var title: TextView
    private val tabViews = ArrayList<TextView>()
    private val tabSpans = intArrayOf(5, 4, 3)
    private var span = 3
    private val fmt = SimpleDateFormat("d 'de' MMM 'de' yyyy", Locale("es"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); fitsSystemWindows = true }
        lm = GridLayoutManager(this, span)
        rv = RecyclerView(this)
        rv.layoutManager = lm
        rv.setPadding(0, dp(64), 0, dp(90))
        rv.clipToPadding = false
        root.addView(rv, FrameLayout.LayoutParams(-1, -1))

        // top scrim + back button + date
        root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xEE000000.toInt(), 0x00000000))
        }, FrameLayout.LayoutParams(-1, dp(96), Gravity.TOP))
        root.addView(TextView(this).apply {
            text = "‹"; setTextColor(Color.WHITE); textSize = 24f; gravity = Gravity.CENTER
            background = round(0x55333333, 20); setOnClickListener { finish() }
        }, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.START).apply { setMargins(dp(14), dp(10), 0, 0) })
        title = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 21f; setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(66), dp(16), 0, 0) })

        // floating tab pill
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = round(0xDD2C2C2E.toInt(), 30)
            setPadding(dp(4), dp(4), dp(4), dp(4)); elevation = dp(8).toFloat()
        }
        listOf("Años", "Meses", "Todas las fotos").forEachIndexed { i, l ->
            val tv = TextView(this).apply {
                text = l; textSize = 14f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(16), dp(9), dp(16), dp(9))
                setOnClickListener { setSpan(tabSpans[i]) }
            }
            pill.addView(tv); tabViews.add(tv)
        }
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(24) })
        updateTabs()
        setContentView(root)

        adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = uris.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val iv = ImageView(p.context)
                val size = p.width / span
                iv.layoutParams = ViewGroup.LayoutParams(size, size)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.setPadding(1, 1, 1, 1)
                iv.setBackgroundColor(0xFF111111.toInt())
                return object : RecyclerView.ViewHolder(iv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val iv = h.itemView as ImageView
                val gi = uris.size - 1 - pos            // grid shows oldest -> newest
                iv.tag = gi
                iv.animate().cancel(); iv.scaleX = 1f; iv.scaleY = 1f
                iv.setOnTouchListener { v, e ->      // little "press" like iOS
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                    }
                    false
                }
                iv.setOnClickListener {
                    val o = ActivityOptions.makeScaleUpAnimation(it, it.width / 2, it.height / 2, 0, 0)
                    startActivity(Intent(this@GridActivity, GalleryActivity::class.java).putExtra("pos", gi), o.toBundle())
                }
                val c = cache.get(gi)
                if (c != null) { iv.alpha = 1f; iv.setImageBitmap(c); return }
                iv.setImageDrawable(null)
                iv.alpha = 0f
                pool.execute {
                    val b = Media.decode(this@GridActivity, uris[gi], 384)
                    if (b != null) {
                        cache.put(gi, b)
                        runOnUiThread {
                            if (iv.tag == gi) { iv.setImageBitmap(b); iv.animate().alpha(1f).setDuration(180).start() }
                        }
                    }
                }
            }
        }
        rv.adapter = adapter
        rv.itemAnimator = null

        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) = updateTitle()
        })

        // pinch: more / fewer columns
        var acc = 1f
        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                acc *= d.scaleFactor
                if (acc > 1.25f && span > 3) { setSpan(span - 1); acc = 1f }
                else if (acc < 0.8f && span < 5) { setSpan(span + 1); acc = 1f }
                return true
            }
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { acc = 1f; return true }
        })
        rv.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(r: RecyclerView, e: MotionEvent): Boolean {
                scaler.onTouchEvent(e); return scaler.isInProgress
            }
        })
    }

    private fun updateTabs() = tabViews.forEachIndexed { i, tv ->
        val sel = tabSpans[i] == span
        tv.setTextColor(if (sel) Color.WHITE else 0xFFAAAAAA.toInt())
        tv.background = if (sel) round(0x66FFFFFF, 26) else null
    }

    private fun setSpan(n: Int) {
        if (n == span) return
        val first = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
        span = n
        updateTabs()
        rv.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(110).withEndAction {
            lm.spanCount = span
            rv.adapter = adapter
            rv.scrollToPosition(first)
            rv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }.start()
    }

    private fun updateTitle() {
        if (uris.isEmpty()) return
        val pos = lm.findFirstVisibleItemPosition().coerceIn(0, uris.size - 1)
        val gi = uris.size - 1 - pos
        val t = dates.getOrNull(gi) ?: return
        val s = fmt.format(Date(t))
        if (title.text != s) title.text = s
    }

    private fun query(): Pair<List<Uri>, List<Long>> {
        val u = ArrayList<Uri>(); val d = ArrayList<Long>()
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID, MediaStore.MediaColumns.DATE_ADDED),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    u.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0)))
                    d.add(c.getLong(1) * 1000)
                }
            }
        } catch (_: Exception) {}
        return u to d
    }

    override fun onResume() {
        super.onResume()
        Thread {
            val (l, d) = query()
            runOnUiThread {
                if (l.size != uris.size) {
                    uris = l; dates = d
                    cache.evictAll()
                    adapter.notifyDataSetChanged()
                    if (l.isNotEmpty()) rv.scrollToPosition(l.size - 1)
                    rv.post { updateTitle() }
                }
            }
        }.start()
    }
}

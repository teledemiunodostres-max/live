package com.example.livecam

import android.app.ActivityOptions
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Photos-style zoom levels (pinch or tabs):
 * Años -> Meses -> 16 columns -> 10 columns -> 5 columns -> viewer.
 * Tap a year -> months; tap a month -> that month in 16 columns; tap a photo (16/10) -> 5 columns at that photo; tap again -> viewer.
 */
class GridActivity : AppCompatActivity() {
    private class Group(val title: String, val key: String, val gis: List<Int>)   // gis: oldest -> newest

    private var uris: List<Uri> = emptyList()      // newest first (same order as GalleryActivity)
    private var dates: List<Long> = emptyList()
    private var allGis: List<Int> = emptyList()    // display order: oldest -> newest
    private var list: List<Int> = emptyList()      // photos shown in the photo levels
    private var months: List<Group> = emptyList()
    private var years: List<Group> = emptyList()
    private var filter: Group? = null              // month opened from "Meses"
    private var lvl = 4                            // 0 Años, 1 Meses, 2 = 16 cols, 3 = 10 cols, 4 = 5 cols
    private val spans = intArrayOf(1, 1, 16, 10, 5)

    private val cache = LruCache<Long, Bitmap>(700)
    private val pool = Executors.newFixedThreadPool(4)
    private lateinit var rv: RecyclerView
    private lateinit var lm: GridLayoutManager
    private lateinit var adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>
    private lateinit var title: TextView
    private val tabViews = ArrayList<TextView>()
    private val dayFmt = SimpleDateFormat("d 'de' MMM 'de' yyyy", Locale("es"))
    private val monthFmt = SimpleDateFormat("MMMM 'de' yyyy", Locale("es"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun groups() = if (lvl == 0) years else months

    private class Card(val root: LinearLayout, val label: TextView, val cells: List<ImageView>) : RecyclerView.ViewHolder(root)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); fitsSystemWindows = true }
        lm = GridLayoutManager(this, spans[lvl])
        rv = RecyclerView(this)
        rv.layoutManager = lm
        rv.setPadding(0, dp(64), 0, dp(90))
        rv.clipToPadding = false
        root.addView(rv, FrameLayout.LayoutParams(-1, -1))

        root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xEE000000.toInt(), 0x00000000))
        }, FrameLayout.LayoutParams(-1, dp(96), Gravity.TOP))
        root.addView(TextView(this).apply {
            text = "‹"; setTextColor(Color.WHITE); textSize = 24f; gravity = Gravity.CENTER
            background = round(0x55333333, 20); setOnClickListener { goBack() }
        }, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.START).apply { setMargins(dp(14), dp(10), 0, 0) })
        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 21f; setTypeface(typeface, Typeface.BOLD) }
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(66), dp(16), 0, 0) })

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = round(0xDD2C2C2E.toInt(), 30)
            setPadding(dp(4), dp(4), dp(4), dp(4)); elevation = dp(8).toFloat()
        }
        val tabLvl = intArrayOf(0, 1, 4)
        listOf("Años", "Meses", "Todas las fotos").forEachIndexed { i, l ->
            val tv = TextView(this).apply {
                text = l; textSize = 14f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(16), dp(9), dp(16), dp(9))
                setOnClickListener { filter = null; setLevel(tabLvl[i], anchor()) }
            }
            pill.addView(tv); tabViews.add(tv)
        }
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(24) })
        setContentView(root)

        adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = if (lvl < 2) groups().size else list.size
            override fun getItemViewType(p: Int) = if (lvl < 2) 1 else 0
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                if (t == 1) return makeCard(p.context)
                val iv = ImageView(p.context)
                val size = rv.width / spans[lvl]
                iv.layoutParams = ViewGroup.LayoutParams(size, size)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val pd = if (spans[lvl] >= 16) 0 else 1
                iv.setPadding(pd, pd, pd, pd)
                iv.setBackgroundColor(0xFF111111.toInt())
                return object : RecyclerView.ViewHolder(iv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                if (h is Card) { bindCard(h, groups()[pos]); return }
                val iv = h.itemView as ImageView
                val gi = list[pos]
                load(iv, gi, when (spans[lvl]) { 5 -> 384; 10 -> 200; else -> 128 })
                iv.setOnClickListener {
                    if (lvl == 4) {
                        val o = ActivityOptions.makeScaleUpAnimation(it, it.width / 2, it.height / 2, 0, 0)
                        startActivity(Intent(this@GridActivity, GalleryActivity::class.java).putExtra("pos", gi), o.toBundle())
                    } else { filter = null; setLevel(4, gi) }   // 16/10 -> 5 columns where that photo is
                }
            }
        }
        rv.adapter = adapter
        rv.itemAnimator = null
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) = updateTitle()
        })

        // pinch: one zoom level per gesture (spread = closer, pinch = further)
        var acc = 1f; var stepped = false
        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                acc *= d.scaleFactor
                if (!stepped) {
                    if (acc > 1.15f && lvl < 4) { stepped = true; filter = null; setLevel(lvl + 1, anchor()) }
                    else if (acc < 0.87f && lvl > 0) { stepped = true; filter = null; setLevel(lvl - 1, anchor()) }
                }
                return true
            }
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { acc = 1f; stepped = false; return true }
        })
        rv.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(r: RecyclerView, e: MotionEvent): Boolean { scaler.onTouchEvent(e); return scaler.isInProgress }
            override fun onTouchEvent(r: RecyclerView, e: MotionEvent) { scaler.onTouchEvent(e) }
            override fun onRequestDisallowInterceptTouchEvent(d: Boolean) {}
        })
        updateTabs()
    }

    // ---------- Month / year summary cards (hero photo + 4 random photos) ----------

    private fun makeCard(ctx: android.content.Context): Card {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(10))
            layoutParams = ViewGroup.LayoutParams(-1, -2)
        }
        val label = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 20f; setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), 0, 0, dp(6)) }
        box.addView(label)
        val cells = ArrayList<ImageView>()
        fun cell() = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF111111.toInt()); cells.add(this)
        }
        val side = (rv.width - dp(20)) / 2
        val mosaic = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        mosaic.addView(cell(), LinearLayout.LayoutParams(0, side, 1f).apply { setMargins(0, 0, dp(2), 0) })
        val right = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        repeat(2) { r ->
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(cell(), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(0, 0, dp(2), 0) })
            row.addView(cell(), LinearLayout.LayoutParams(0, -1, 1f))
            right.addView(row, LinearLayout.LayoutParams(-1, 0, 1f).apply { if (r == 0) bottomMargin = dp(2) })
        }
        mosaic.addView(right, LinearLayout.LayoutParams(0, side, 1f))
        box.addView(mosaic, LinearLayout.LayoutParams(-1, side))
        return Card(box, label, cells)
    }

    private fun bindCard(c: Card, g: Group) {
        c.label.text = g.title
        val pick = g.gis.shuffled(kotlin.random.Random(g.key.hashCode()))   // stable "random" picks
        c.cells.forEachIndexed { i, iv ->
            val gi = pick.getOrNull(i)
            if (gi == null) { iv.tag = null; iv.setImageDrawable(null) } else load(iv, gi, if (i == 0) 384 else 200)
        }
        c.root.setOnClickListener {
            if (lvl == 0) { filter = null; setLevel(1, g.gis.first()) }
            else { filter = g; setLevel(2, g.gis.first(), keepFilter = true) }
        }
    }

    private fun load(iv: ImageView, gi: Int, side: Int) {
        iv.tag = gi
        val key = gi * 1000L + side
        cache.get(key)?.let { iv.setImageBitmap(it); return }
        iv.setImageDrawable(null)
        val u = uris.getOrNull(gi) ?: return
        pool.execute {
            val b = Media.decode(this, u, side)
            if (b != null) { cache.put(key, b); runOnUiThread { if (iv.tag == gi) iv.setImageBitmap(b) } }
        }
    }

    // ---------- Levels ----------

    /** Photo (gi) the user is looking at, to keep the position when changing level. */
    private fun anchor(): Int {
        if (uris.isEmpty()) return -1
        val p = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
        return if (lvl >= 2) list.getOrNull(p) ?: -1 else groups().getOrNull(p)?.gis?.first() ?: -1
    }

    private fun setLevel(n: Int, anchor: Int, keepFilter: Boolean = false) {
        if (!keepFilter) filter = null
        if (n == lvl && filter == null && list === allGis) return
        rv.animate().cancel()
        rv.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(100).withEndAction {
            lvl = n
            list = filter?.gis ?: allGis
            lm.spanCount = spans[n]
            rv.adapter = adapter
            val pos = if (n >= 2) list.indexOf(anchor) else groups().indexOfFirst { anchor in it.gis }
            if (pos >= 0) lm.scrollToPositionWithOffset(pos, 0) else rv.scrollToPosition((adapter.itemCount - 1).coerceAtLeast(0))
            updateTabs(); updateTitle()
            rv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
        }.start()
    }

    private fun updateTabs() = tabViews.forEachIndexed { i, tv ->
        val sel = (i == 0 && lvl == 0) || (i == 1 && lvl == 1) || (i == 2 && lvl >= 2)
        tv.setTextColor(if (sel) Color.WHITE else 0xFFAAAAAA.toInt())
        tv.background = if (sel) round(0x66FFFFFF, 26) else null
    }

    private fun updateTitle() {
        if (uris.isEmpty()) return
        val f = filter
        val s = when {
            lvl == 0 -> "Años"
            lvl == 1 -> "Meses"
            f != null -> f.title
            else -> {
                val gi = list.getOrNull(lm.findFirstVisibleItemPosition().coerceAtLeast(0)) ?: return
                dayFmt.format(Date(dates.getOrElse(gi) { return }))
            }
        }
        if (title.text != s) title.text = s
    }

    private fun goBack() {
        val f = filter
        if (f != null) setLevel(1, f.gis.first()) else finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (filter != null) goBack() else super.onBackPressed() }

    // ---------- Data ----------

    private fun query(): Pair<List<Uri>, List<Long>> {
        val u = ArrayList<Uri>(); val d = ArrayList<Long>()
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID, MediaStore.MediaColumns.DATE_ADDED),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    u.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0)))
                    d.add(c.getLong(1) * 1000)
                }
            }
        } catch (_: Exception) {}
        return u to d
    }

    private fun rebuild() {
        allGis = List(uris.size) { uris.size - 1 - it }
        val cal = Calendar.getInstance()
        val mm = LinkedHashMap<String, MutableList<Int>>(); val yy = LinkedHashMap<String, MutableList<Int>>()
        for (gi in allGis) {
            cal.timeInMillis = dates[gi]
            val y = cal.get(Calendar.YEAR)
            mm.getOrPut("$y-${cal.get(Calendar.MONTH) + 1}") { ArrayList() }.add(gi)
            yy.getOrPut("$y") { ArrayList() }.add(gi)
        }
        months = mm.map { (k, v) -> Group(monthFmt.format(Date(dates[v.first()])).replaceFirstChar { it.uppercase() }, k, v) }
        years = yy.map { (k, v) -> Group(k, k, v) }
    }

    override fun onResume() {
        super.onResume()
        Thread {
            val (l, d) = query()
            runOnUiThread {
                if (l.size != uris.size) {
                    uris = l; dates = d
                    cache.evictAll()
                    filter = null
                    rebuild()
                    list = allGis
                    adapter.notifyDataSetChanged()
                    if (l.isNotEmpty()) rv.scrollToPosition(adapter.itemCount - 1)
                    rv.post { updateTitle() }
                }
            }
        }.start()
    }
}

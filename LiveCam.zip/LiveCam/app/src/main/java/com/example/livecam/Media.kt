package com.example.livecam

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import java.nio.ByteBuffer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.content.ContentValues
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

object Media {
    fun queryLive(ctx: Context): List<Uri> {
        val out = ArrayList<Uri>()
        try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (c.moveToNext()) {
                    out.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun queryLiveDates(ctx: Context): List<Long> {
        val out = ArrayList<Long>()
        try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.MediaColumns.DATE_ADDED),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { c -> while (c.moveToNext()) out.add(c.getLong(0) * 1000) }
        } catch (_: Exception) {}
        return out
    }

    /** Decodes with the longest side <= maxSide (fast: JPEG scaled while decoding). */
    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > maxSide) s *= 2
        val bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
        val deg = cr.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        if (bmp != null && deg != 0f)
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        else bmp
    } catch (e: Exception) {
        null
    }

    class LiveMeta(val startMs: Int, val burst: Int, val id: String?, val idx: Int, val offsetUs: Long = 0L, val full: Boolean = false)


    private val metaCache = java.util.concurrent.ConcurrentHashMap<Uri, LiveMeta>()

    fun liveMeta(ctx: Context, uri: Uri): LiveMeta = metaCache[uri] ?: readMeta(ctx, uri).also { metaCache[uri] = it }

    private fun readMeta(ctx: Context, uri: Uri): LiveMeta = try {
        val b = ByteArray(300_000)
        var ins = if (Build.VERSION.SDK_INT >= 29) try {
            ctx.contentResolver.openInputStream(MediaStore.setRequireOriginal(uri))
        } catch (_: Exception) { null } else null
        if (ins == null) ins = ctx.contentResolver.openInputStream(uri)
        val n = ins!!.use { it.read(b) }
        val head = String(b, 0, maxOf(n, 0), Charsets.ISO_8859_1)
        fun g(k: String) = Regex("LiveCam:$k=\"([^\"]+)\"").find(head)?.groupValues?.get(1)
        LiveMeta((g("StartUs")?.toLongOrNull() ?: 0L).div(1000).toInt(), g("Burst")?.toIntOrNull() ?: 1,
            g("BurstId"), g("BurstIdx")?.toIntOrNull() ?: 0, g("OffsetUs")?.toLongOrNull() ?: 0L, g("Full") == "1")
    } catch (e: Exception) {
        LiveMeta(0, 1, null, 0)
    }

    fun startMs(ctx: Context, uri: Uri): Int = liveMeta(ctx, uri).startMs

    @Volatile var lastErr: String? = null

    /** Joins the burst's clips into ONE long video in the cache (deleted when leaving the gallery/app). */
    fun buildLong(ctx: Context, uris: List<Uri>, p: Int, first: LiveMeta): File? = try {
        val out = File(ctx.cacheDir, "long_${first.id}.mp4")
        if (out.exists() && out.length() > 0) out else {
            val parts = ArrayList<Pair<LiveMeta, Uri>>()
            parts.add(first to uris[p])
            var k = 1
            while (parts.size < first.burst && k <= first.burst + 6) {
                val u = uris.getOrNull(p + k++) ?: break
                val m = liveMeta(ctx, u)
                if (m.id == first.id) parts.add(m to u)
            }
            if (parts.size < 2) null else {
                parts.sortBy { it.first.idx }
                val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
                val files = try {
                    pool.invokeAll(parts.map { pt -> java.util.concurrent.Callable { extractVideo(ctx, pt.second) } })
                        .map { it.get() ?: throw IllegalStateException("clip") }
                } finally { pool.shutdown() }
                val rot = MediaMetadataRetriever().let { r ->
                    r.setDataSource(files[0].path)
                    val v = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    r.release(); v
                }
                val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                mux.setOrientationHint(rot)
                var vt = -1; var at = -1
                var lastV = Long.MIN_VALUE; var lastA = Long.MIN_VALUE; var removed = 0L
                val buf = ByteBuffer.allocate(4_000_000)
                val info = MediaCodec.BufferInfo()
                run {
                    val ex = MediaExtractor(); ex.setDataSource(files[0].path)
                    for (t in 0 until ex.trackCount) {
                        val f = ex.getTrackFormat(t); val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("video") && vt < 0) vt = mux.addTrack(f)
                        else if (mime.startsWith("audio") && at < 0) at = mux.addTrack(f)
                    }
                    ex.release()
                }
                mux.start()
                for ((ci, f) in files.withIndex()) {
                    val off = parts[ci].first.offsetUs
                    // each clip starts on a key frame: cut the previous clip right where the next one begins
                    val endLim = if (ci + 1 < parts.size) parts[ci + 1].first.offsetUs else Long.MAX_VALUE
                    val ex = MediaExtractor(); ex.setDataSource(f.path)
                    var vi = -1; var ai = -1
                    for (t in 0 until ex.trackCount) {
                        val mime = ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("video") && vi < 0) vi = t else if (mime.startsWith("audio") && ai < 0) ai = t
                    }
                    var firstW = true
                    if (vi >= 0) {
                        ex.selectTrack(vi)
                        while (true) {
                            buf.clear()
                            val n = ex.readSampleData(buf, 0); if (n < 0) break
                            val abs = ex.sampleTime + off
                            if (abs >= endLim) break
                            if (abs > lastV) {
                                if (firstW && lastV != Long.MIN_VALUE && abs - lastV > 100_000) removed += abs - lastV - 16_000
                                firstW = false
                                info.set(0, n, abs - removed, ex.sampleFlags)
                                mux.writeSampleData(vt, buf, info)
                                lastV = abs
                            }
                            ex.advance()
                        }
                        ex.unselectTrack(vi)
                    }
                    if (ai >= 0 && at >= 0) {
                        ex.selectTrack(ai)
                        while (true) {
                            buf.clear()
                            val n = ex.readSampleData(buf, 0); if (n < 0) break
                            val abs = ex.sampleTime + off
                            if (abs >= endLim) break
                            if (abs > lastA && abs - removed >= 0) {
                                info.set(0, n, abs - removed, ex.sampleFlags)
                                mux.writeSampleData(at, buf, info)
                                lastA = abs
                            }
                            ex.advance()
                        }
                    }
                    ex.release()
                }
                mux.stop(); mux.release()
                out
            }
        }
    } catch (e: Exception) {
        lastErr = e.message ?: e.javaClass.simpleName
        File(ctx.cacheDir, "long_${first.id}.mp4").delete()
        null
    }

    /** Rewrites an already-saved photo (same gallery entry) with its final Live content. */
    fun overwrite(ctx: Context, uri: Uri, bytes: ByteArray) {
        ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(bytes) }
    }

    private fun readAll(ctx: Context, uri: Uri): ByteArray {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.openInputStream(MediaStore.setRequireOriginal(uri))!!.use { it.readBytes() }
            } catch (_: Exception) {
            }
        }
        return ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    }

    private fun isFtyp(b: ByteArray, st: Int): Boolean =
        st >= 0 && st + 8 <= b.size && b[st + 4] == 'f'.code.toByte() && b[st + 5] == 't'.code.toByte() &&
            b[st + 6] == 'y'.code.toByte() && b[st + 7] == 'p'.code.toByte()

    private fun findMp4Start(b: ByteArray): Int {
        // 1) length declared in the XMP (when the system hasn't stripped it)
        val head = String(b, 0, minOf(b.size, 400_000), Charsets.ISO_8859_1)
        val len = Regex("Item:Semantic=\"MotionPhoto\" Item:Length=\"(\\d+)\"").find(head)
            ?.groupValues?.get(1)?.toIntOrNull()
        if (len != null && len > 0 && len < b.size && isFtyp(b, b.size - len)) return b.size - len
        // 2) fallback: last "ftyp" box in the file
        var i = b.size - 8
        while (i >= 4) {
            if (isFtyp(b, i - 4)) return i - 4
            i--
        }
        return -1
    }

    /** Pulls the MP4 embedded at the end of a Motion Photo (reads only the tail, not the whole file). */
    fun extractVideo(ctx: Context, uri: Uri): File? = try {
        val out = File(ctx.cacheDir, "play_${uri.lastPathSegment}.mp4")
        if (out.exists() && out.length() > 0) out else {
            var pfd: android.os.ParcelFileDescriptor? = null
            if (Build.VERSION.SDK_INT >= 29) try { pfd = ctx.contentResolver.openFileDescriptor(MediaStore.setRequireOriginal(uri), "r") } catch (_: Exception) {}
            if (pfd == null) pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
            var st = -1L
            var size = 0L
            pfd!!.use { p ->
                java.io.FileInputStream(p.fileDescriptor).channel.use { ch ->
                    size = ch.size()
                    val hb = ByteBuffer.allocate(minOf(size, 400_000L).toInt())
                    ch.read(hb, 0)
                    val head = String(hb.array(), 0, hb.position(), Charsets.ISO_8859_1)
                    val len = Regex("Item:Semantic=\"MotionPhoto\" Item:Length=\"(\\d+)\"").find(head)?.groupValues?.get(1)?.toLongOrNull()
                    if (len != null && len > 8 && len < size) {
                        val t = ByteBuffer.allocate(8); ch.read(t, size - len)
                        if (isFtyp(t.array(), 0)) {
                            st = size - len
                            ch.position(st)
                            java.io.FileOutputStream(out).use { fo ->
                                val buf = ByteBuffer.allocate(1 shl 20)
                                while (true) { buf.clear(); val n = ch.read(buf); if (n < 0) break; fo.write(buf.array(), 0, n) }
                            }
                        }
                    }
                }
            }
            if (st >= 0) out else {
                val bytes = readAll(ctx, uri)
                val s2 = findMp4Start(bytes)
                if (s2 < 0) null else out.also { it.writeBytes(bytes.copyOfRange(s2, bytes.size)) }
            }
        }
    } catch (e: Exception) {
        null
    }

    fun pack(jpeg: ByteArray, mp4: ByteArray, presUs: Long): ByteArray {
        val xmp = """
            <x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:GCamera="http://ns.google.com/photos/1.0/camera/" xmlns:Container="http://ns.google.com/photos/1.0/container/" xmlns:Item="http://ns.google.com/photos/1.0/container/item/" GCamera:MotionPhoto="1" GCamera:MotionPhotoVersion="1" GCamera:MotionPhotoPresentationTimestampUs="$presUs"><Container:Directory><rdf:Seq><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/></rdf:li><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/></rdf:li></rdf:Seq></Container:Directory></rdf:Description></rdf:RDF></x:xmpmeta>
        """.trimIndent()
        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val xmpBytes = xmp.toByteArray(Charsets.UTF_8)
        val segLen = 2 + header.size + xmpBytes.size

        // Insert after the existing APP0/APP1 (EXIF) segments
        var pos = 2
        while (pos + 4 < jpeg.size && (jpeg[pos].toInt() and 0xFF) == 0xFF) {
            val m = jpeg[pos + 1].toInt() and 0xFF
            if (m != 0xE0 && m != 0xE1) break
            val len = ((jpeg[pos + 2].toInt() and 0xFF) shl 8) or (jpeg[pos + 3].toInt() and 0xFF)
            pos += 2 + len
        }
        val out = ByteArrayOutputStream(jpeg.size + mp4.size + segLen + 4)
        out.write(jpeg, 0, pos)
        out.write(0xFF); out.write(0xE1)
        out.write(segLen shr 8); out.write(segLen and 0xFF)
        out.write(header); out.write(xmpBytes)
        out.write(jpeg, pos, jpeg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }


    fun save(ctx: Context, bytes: ByteArray): Uri {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_${name}_k.MP")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiveCam")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo guardar")
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        return uri
    }
}

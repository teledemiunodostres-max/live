package com.example.livecam

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.MediaStore
import java.io.File

object Media {
    fun queryLive(ctx: Context): List<Uri> {
        val out = ArrayList<Uri>()
        try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (c.moveToNext()) {
                    out.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun decode(ctx: Context, uri: Uri, sample: Int): Bitmap? = try {
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        val deg = ctx.contentResolver.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        if (bmp != null && deg != 0f)
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        else bmp
    } catch (e: Exception) {
        null
    }

    /** Pulls the MP4 embedded at the end of a Motion Photo and saves it in the cache. */
    fun extractVideo(ctx: Context, uri: Uri): File? = try {
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val head = String(bytes, 0, minOf(bytes.size, 200_000), Charsets.ISO_8859_1)
        val m = Regex("Item:Semantic=\"MotionPhoto\" Item:Length=\"(\\d+)\"").find(head)
        val len = m?.groupValues?.get(1)?.toIntOrNull()
        if (len == null || len <= 0 || len > bytes.size) null
        else File(ctx.cacheDir, "play_${uri.lastPathSegment}.mp4").also {
            it.writeBytes(bytes.copyOfRange(bytes.size - len, bytes.size))
        }
    } catch (e: Exception) {
        null
    }
}

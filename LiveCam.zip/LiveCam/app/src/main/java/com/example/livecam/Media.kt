package com.example.livecam

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.content.ContentValues
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

object Media {
    fun queryLive(ctx: Context): List<Uri> {
        val out = ArrayList<Uri>()
        try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (c.moveToNext()) {
                    out.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** Decodes with the longest side <= maxSide (fast: JPEG scaled while decoding). */
    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > maxSide) s *= 2
        val bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
        val deg = cr.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        if (bmp != null && deg != 0f)
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        else bmp
    } catch (e: Exception) {
        null
    }

    /** Where this photo's Live starts inside the shared clip (burst photos start later). */
    fun startMs(ctx: Context, uri: Uri): Int = try {
        val b = ByteArray(300_000)
        var ins = if (Build.VERSION.SDK_INT >= 29) try {
            ctx.contentResolver.openInputStream(MediaStore.setRequireOriginal(uri))
        } catch (_: Exception) { null } else null
        if (ins == null) ins = ctx.contentResolver.openInputStream(uri)
        val n = ins!!.use { it.read(b) }
        val head = String(b, 0, maxOf(n, 0), Charsets.ISO_8859_1)
        (Regex("LiveCam:StartUs=\"(\\d+)\"").find(head)?.groupValues?.get(1)?.toLongOrNull() ?: 0L).div(1000).toInt()
    } catch (e: Exception) {
        0
    }

    private fun readAll(ctx: Context, uri: Uri): ByteArray {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.openInputStream(MediaStore.setRequireOriginal(uri))!!.use { it.readBytes() }
            } catch (_: Exception) {
            }
        }
        return ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    }

    private fun isFtyp(b: ByteArray, st: Int): Boolean =
        st >= 0 && st + 8 <= b.size && b[st + 4] == 'f'.code.toByte() && b[st + 5] == 't'.code.toByte() &&
            b[st + 6] == 'y'.code.toByte() && b[st + 7] == 'p'.code.toByte()

    private fun findMp4Start(b: ByteArray): Int {
        // 1) length declared in the XMP (when the system hasn't stripped it)
        val head = String(b, 0, minOf(b.size, 400_000), Charsets.ISO_8859_1)
        val len = Regex("Item:Semantic=\"MotionPhoto\" Item:Length=\"(\\d+)\"").find(head)
            ?.groupValues?.get(1)?.toIntOrNull()
        if (len != null && len > 0 && len < b.size && isFtyp(b, b.size - len)) return b.size - len
        // 2) fallback: last "ftyp" box in the file
        var i = b.size - 8
        while (i >= 4) {
            if (isFtyp(b, i - 4)) return i - 4
            i--
        }
        return -1
    }

    /** Pulls the MP4 embedded at the end of a Motion Photo and saves it in the cache. */
    fun extractVideo(ctx: Context, uri: Uri): File? = try {
        val out = File(ctx.cacheDir, "play_${uri.lastPathSegment}.mp4")
        if (out.exists() && out.length() > 0) {
            out
        } else {
            val bytes = readAll(ctx, uri)
            val st = findMp4Start(bytes)
            if (st < 0) null else out.also { it.writeBytes(bytes.copyOfRange(st, bytes.size)) }
        }
    } catch (e: Exception) {
        null
    }

    fun pack(jpeg: ByteArray, mp4: ByteArray, presUs: Long): ByteArray {
        val xmp = """
            <x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" xmlns:GCamera="http://ns.google.com/photos/1.0/camera/" xmlns:Container="http://ns.google.com/photos/1.0/container/" xmlns:Item="http://ns.google.com/photos/1.0/container/item/" GCamera:MotionPhoto="1" GCamera:MotionPhotoVersion="1" GCamera:MotionPhotoPresentationTimestampUs="$presUs"><Container:Directory><rdf:Seq><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/></rdf:li><rdf:li rdf:parseType="Resource"><Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/></rdf:li></rdf:Seq></Container:Directory></rdf:Description></rdf:RDF></x:xmpmeta>
        """.trimIndent()
        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val xmpBytes = xmp.toByteArray(Charsets.UTF_8)
        val segLen = 2 + header.size + xmpBytes.size

        // Insert after the existing APP0/APP1 (EXIF) segments
        var pos = 2
        while (pos + 4 < jpeg.size && (jpeg[pos].toInt() and 0xFF) == 0xFF) {
            val m = jpeg[pos + 1].toInt() and 0xFF
            if (m != 0xE0 && m != 0xE1) break
            val len = ((jpeg[pos + 2].toInt() and 0xFF) shl 8) or (jpeg[pos + 3].toInt() and 0xFF)
            pos += 2 + len
        }
        val out = ByteArrayOutputStream(jpeg.size + mp4.size + segLen + 4)
        out.write(jpeg, 0, pos)
        out.write(0xFF); out.write(0xE1)
        out.write(segLen shr 8); out.write(segLen and 0xFF)
        out.write(header); out.write(xmpBytes)
        out.write(jpeg, pos, jpeg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }


    fun save(ctx: Context, bytes: ByteArray): Uri {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_${name}_k.MP")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiveCam")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo guardar")
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        return uri
    }
}

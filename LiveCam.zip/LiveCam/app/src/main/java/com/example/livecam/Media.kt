package com.example.livecam

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File

object Media {
    fun queryLive(ctx: Context): List<Uri> {
        val out = ArrayList<Uri>()
        try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?", arrayOf("LIVE_%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (c.moveToNext()) {
                    out.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun decode(ctx: Context, uri: Uri, sample: Int): Bitmap? = try {
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        val deg = ctx.contentResolver.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        if (bmp != null && deg != 0f)
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        else bmp
    } catch (e: Exception) {
        null
    }

    private fun readAll(ctx: Context, uri: Uri): ByteArray {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.openInputStream(MediaStore.setRequireOriginal(uri))!!.use { it.readBytes() }
            } catch (_: Exception) {
            }
        }
        return ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    }

    private fun isFtyp(b: ByteArray, st: Int): Boolean =
        st >= 0 && st + 8 <= b.size && b[st + 4] == 'f'.code.toByte() && b[st + 5] == 't'.code.toByte() &&
            b[st + 6] == 'y'.code.toByte() && b[st + 7] == 'p'.code.toByte()

    private fun findMp4Start(b: ByteArray): Int {
        // 1) length declared in the XMP (when the system hasn't stripped it)
        val head = String(b, 0, minOf(b.size, 400_000), Charsets.ISO_8859_1)
        val len = Regex("Item:Semantic=\"MotionPhoto\" Item:Length=\"(\\d+)\"").find(head)
            ?.groupValues?.get(1)?.toIntOrNull()
        if (len != null && len > 0 && len < b.size && isFtyp(b, b.size - len)) return b.size - len
        // 2) fallback: last "ftyp" box in the file
        var i = b.size - 8
        while (i >= 4) {
            if (isFtyp(b, i - 4)) return i - 4
            i--
        }
        return -1
    }

    /** Pulls the MP4 embedded at the end of a Motion Photo and saves it in the cache. */
    fun extractVideo(ctx: Context, uri: Uri): File? = try {
        val out = File(ctx.cacheDir, "play_${uri.lastPathSegment}.mp4")
        if (out.exists() && out.length() > 0) {
            out
        } else {
            val bytes = readAll(ctx, uri)
            val st = findMp4Start(bytes)
            if (st < 0) null else out.also { it.writeBytes(bytes.copyOfRange(st, bytes.size)) }
        }
    } catch (e: Exception) {
        null
    }
}
